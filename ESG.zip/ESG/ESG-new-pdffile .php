<!-- index-1  -->
<table border="0" cellpadding="0" cellspacing="0" align="center">
    <tr>
        <td colspan="5" height="41">&nbsp;</td>
    </tr>
    <tr>
        <td></td>
        <td align="center" style="padding:9px;">
            <img src="<?php echo $filePath; ?>/images/1.jpg" alt="ist" valign="middle" width="364" height="290" />
        </td>
        <td colspan="2" height="290" valign="middle" style="color:#fff; height: 100%; background: url(<?php echo $filePath; ?>/images/pattern1.png); background-repeat: no-repeat; background-position: right center; padding: 0 40px;">
            <h1 style="font-family: 'lato-heavy';  font-size: 67px; font-weight: 900;"> SUSTAINABILITY<br />REPORT</h1>
        </td>
    </tr>
    <tr>
        <td style=" padding: 9px; padding-left: 0;">
            <img src="<?php echo $filePath; ?>/images/pattern2.png" width="113" height="290" alt="2nd pattern">
        </td>
        <td style="padding: 9px; ">
            <img src="<?php echo $filePath; ?>/images/2.jpg" alt="ist" width="364" height="290" />
        </td>
        <td colspan="" style="padding: 9px;">
            <img src="<?php echo $filePath; ?>/images/3.jpg" width="363" height="290" alt="ist" />
        </td>
        <td width="238" style="color: #203d71; padding: 9px;" valign="top">
            <h1 style="font-family: 'montserrat-bold'; font-size: 67px; font-weight: 900; margin:0;">2021</h1>
        </td>
    </tr>
    <tr>
        <td width="">&nbsp;</td>
        <td colspan="3" align="left" style="padding-top: 9px; padding-left: 40px;">
            <img src="<?php echo $filePath; ?>/images/Asset-6.jpg" width="598" height="40" alt="Asset-6">
        </td>
    </tr>
</table>


<!-- index-2  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index2.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="794" width="541">
        </td>
        <td valign="top" style=" width: 581px; padding-left:37px; padding-right: 27px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td colspan="3" style=" padding-top: 77px; padding-bottom: 25px;">
                        <h1 style="font-family: 'lato-heavy'; font-size: 43px; font-weight: 900; color: #203d71;">TABLE OF CONTENTS</h1>
                    </td>
                </tr>
                <tr>
                    <td>
                        <!-- 1 -->
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td width="60" style="font-family: 'lato-regular'; font-size: 43px; font-weight: 500; color: #abd28c;">01</td>
                                <td style="font-family: 'lato-heavy'; font-size: 24px; font-weight: 800; color: #abd28c;">About This Report</td>
                                <td align="right" style="font-family: 'avenir-lt-std-book'; font-size: 16px; font-weight: 500; color: #abd28c;">PAGE 04</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td style="font-family: 'avenir-lt-std-roman'; line-height: 1.4; font-size: 16px;">
                                    <p>About This Report</p>
                                    <p>Key Achievements of 2021</p>
                                    <p>CEO Statement</p>
                                </td>
                            </tr>
                        </table>

                        <!-- 2 -->
                        <table cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td height="50"></td>
                            </tr>
                            <tr>
                                <td width="60" style="font-family: 'lato-regular'; font-size: 43px; font-weight: 500; color: #abd28c;">02</td>
                                <td style="font-family: 'lato-heavy'; font-size: 24px; font-weight: 800; color: #abd28c;">About Abu Dhabi National Hotels</td>
                                <td align="right" style="font-family: 'avenir-lt-std-book'; font-size: 16px; font-weight: 500; color: #abd28c;">PAGE 08</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td style="font-family: 'avenir-lt-std-roman'; line-height: 1.4; font-size: 16px;">
                                    <p>XYZ (Company Name) At A Glance</p>
                                    <p>History</p>
                                    <p>Financial Performance</p>
                                    <p>Response to Covid-19</p>
                                    <p>2022 Goals</p>
                                </td>
                            </tr>
                        </table>

                        <!-- 3 -->
                        <table cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td height="50"></td>
                            </tr>
                            <tr>
                                <td width="60" style="font-family: 'lato-regular'; font-size: 43px; font-weight: 500; color: #abd28c;">03</td>
                                <td style="font-family: 'lato-heavy'; font-size: 24px; font-weight: 800; color: #abd28c;">Environmental Stewardship</td>
                                <td align="right" style="font-family: 'avenir-lt-std-book'; font-size: 16px; font-weight: 500; color: #abd28c;">PAGE 24</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td style="font-family: 'avenir-lt-std-roman'; line-height: 1.4; font-size: 16px;">
                                    <p>Environmental Initiatives</p>
                                    <p>Energy & Water Consumption</p>
                                    <p>Waste Management</p>
                                    <p>GHG Emissions</p>
                                    <p>2022 Goals</p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-3  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index3.jpg'); background-repeat: no-repeat;">
    <tr>
        <td valign="top" width="560" style=" padding-left:60px; padding-right: 52px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td style="height: 160px;"></td>
                </tr>
                <tr>
                    <td>
                        <!-- 1 -->
                        <table cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td width="68" style="font-family: 'lato-regular'; font-size: 43px; font-weight: 500; color: #abd28c;">04</td>
                                <td width="300" style="font-family: 'lato-heavy'; font-size: 24px; font-weight: 800; color: #abd28c;">Social Stewardship</td>
                                <td align="right" style="font-family: 'avenir-lt-std-book'; font-size: 16px; font-weight: 500; color: #abd28c;">PAGE 37</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td style="font-family: 'avenir-lt-std-roman'; line-height: 1.4; font-size: 16px;">
                                    <p>Human Assets</p>
                                    <p>Equal Opportunity</p>
                                    <p>Diversity of Employees</p>
                                    <p>Training & Development</p>
                                    <p>Customer Service</p>
                                    <p>2022 Goals</p>
                                </td>
                            </tr>
                        </table>

                        <!-- 2 -->
                        <table cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td height="50"></td>
                            </tr>
                            <tr>
                                <td width="68" style="font-family: 'lato-regular'; font-size: 43px; font-weight: 500; color: #abd28c;">05</td>
                                <td width="300" style="font-family: 'lato-heavy'; font-size: 24px; font-weight: 800; color: #abd28c;">Ethical Governance</td>
                                <td align="right" style="font-family: 'avenir-lt-std-book'; font-size: 16px; font-weight: 500; color: #abd28c;">PAGE 57</td>
                            </tr>
                            <tr>
                                <td></td>
                            </tr>
                        </table>

                        <!-- 3 -->
                        <table cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td height="65"></td>
                            </tr>
                            <tr>
                                <td width="68" style="font-family: 'lato-regular'; font-size: 43px; font-weight: 500; color: #abd28c;">06</td>
                                <td width="300" style="font-family: 'lato-heavy'; font-size: 24px; font-weight: 800; color: #abd28c;">Sustainability Management</td>
                                <td align="right" style="font-family: 'avenir-lt-std-book'; font-size: 16px; font-weight: 500; color: #abd28c;">PAGE 61</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td style="font-family: 'avenir-lt-std-roman'; line-height: 1.4; font-size: 16px;">
                                    <p>Stakeholder Consultation</p>
                                    <p>Materiality Analysis</p>
                                </td>
                            </tr>
                        </table>

                        <!-- 4 -->
                        <table cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td height="35"></td>
                            </tr>
                            <tr>
                                <td width="68" style="font-family: 'lato-regular'; font-size: 43px; font-weight: 500; color: #abd28c;">07</td>
                                <td width="250" style="font-family: 'lato-heavy'; font-size: 24px; font-weight: 800; color: #abd28c;">ADX ESG Index</td>
                                <td align="right" style="font-family: 'avenir-lt-std-book'; font-size: 16px; font-weight: 500; color: #abd28c;">PAGE 67</td>
                            </tr>
                        </table>

                    </td>
                </tr>
            </table>
        </td>
        <td width="562" height="794">
        </td>
    </tr>
</table>


<!-- index-4  -->
<table border="0" cellpadding="0" cellspacing="0" align="center">
    <tr>
        <td width="501" height="794" style="background-image: url('<?php echo $filePath; ?>/images/index4-1.jpg'); background-image-resize: 6; padding-left: 85px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td width="275" style="font-family: 'lato-heavy'; font-size: 45px; font-weight: 800; color: #fff; padding-top: 70px; padding-bottom: 40px;">
                        ABOUT THIS REPORT
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="275" border="0" cellpadding="0" cellspacing="0" style="font-family: 'montserrat'; font-size: 16px; font-weight: 500; color: #fff; line-height: 35px;">
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">About This Report</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">Key Achievements Of 2021</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">CEO Statement</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
        <td bgcolor="#abd28c">
            <img src="<?php echo $filePath; ?>/images/index4-2.jpg" alt="right-img" width="624" height="794" />
        </td>
    </tr>
</table>


<!-- index-5  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index5.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="100%">
            <table width="465" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" align="center" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff;">
                        ABOUT THIS REPORT</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="60">&nbsp;</td>
    </tr>
    <tr>
        <td height="493" width="1122" valign="top">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="80">&nbsp;</td>
                    <td width="565">
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px;">
                            <tr>
                                <td style="padding-top:18px; line-height: 1.38;">
                                    The successes and updates in business performance and sustainability metrics
                                    of the year <span style="color: #ff1616;"> XXXX </span> are proudly announced by <span style="color: #ff1616;"> XYZ (Company Name).</span>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding-top:18px; line-height: 1.38;">This year’s Environmental, Social, and Governance (ESG) Performance Report
                                    offers a glimpse into the ways in which we have implemented our
                                    sustainability goals and improved the way in which we operate.
                                </td>
                            </tr>
                            <tr>
                                <td style="padding-top:18px; line-height: 1.38;">In response to imminent climate change challenges, we have treaded carefully
                                    to service our clients while remaining sustainable and supporting our staff. We
                                    reiterate that the information included in this report complies with <span style="color: #ff1616;"> ADX/DFM</span>
                                    ESG Guidelines and is consistent with GRI Standards and UN Sustainable
                                    Development Goals (UNSDGs). Abiding by our belief in transparency and
                                    developing our stakeholder's trust year by year, we hereby share with you our
                                    performance report and the growth we have experienced this year on ESG
                                    parameters.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-6  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index6.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="100%">
            <table width="465" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" align="center" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff;">KEY ACHIEVEMENTS OF 2021</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
    <tr>
        <td height="523" width="1122" valign="top">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="90">&nbsp;</td>
                    <td width="655" style="font-family: 'avenir-lt-std-roman'; text-align: justify; line-height: 22px; font-size: 16px; color: #ff1616;">
                        <ul>
                            <li style="padding-bottom: 35px;">The Ritz-Carlton Abu Dhabi Grand Canal was awarded Conde Nast Traveler 2021
                                Readers' Choice Awards.
                            </li>
                            <br>
                            <li style="padding-bottom: 35px;">The Ritz-Carlton Abu Dhabi Grand Canal was awarded FACT Dining Awards Abu Dhabi -
                                Li Jiang - The Best Family-Friendly Brunch in Abu Dhabi for Chef’s Brunch.
                            </li>
                            <br>
                            <li style="padding-bottom: 35px;">The Ritz-Carlton Abu Dhabi Grand Canal was awarded #2 in the Top 20 Hotels in the
                                Middle East list</li>
                            <br>
                            <li style="padding-bottom: 35px;">The Ritz-Carlton Abu Dhabi Grand Canal was awarded #12 in The Best Hotels in the
                                World list.
                            </li>
                            <br>
                            <li style="padding-bottom: 35px;">Park Hyatt has been listed as “Sharecare VERIFIED™” with Forbes Travel Guide for the
                                year 2021. It has also been awarded as the “Favourite Mediterranean Restaurant in Abu
                                Dhabi” (Beach House) by Fact Dining Awards.</li>
                            <br>
                            <li style="padding-bottom: 35px;">The Ritz-Carlton Abu Dhabi Grand Canal was awarded FACT Dining Awards Abu Dhabi -
                                Giornotte - Favourite Pan-Asian Restaurant in Abu Dhabi for Li Jiang.</li>
                            <br>
                            <li style="padding-bottom: 35px;">Sofitel Dubai Jumeirah was awarded a Certificate of appreciation for “Clean up UAE
                                2021” issued by the Emirates Environmental Group under the patronage of UAE
                                MOCCAE.
                            </li>
                        </ul>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-7  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index7.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="100%">
            <table width="465" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" align="center" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff;">CEO STATEMENT</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="40">&nbsp;</td>
    </tr>
    <tr>
        <td height="513" width="1122" valign="top">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="80">&nbsp;</td>
                    <td width="673">
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px;">
                            <tr>
                                <td style="font-family: 'lato-heavy'; font-size: 16px; font-weight: 800; color: #21305c;">
                                    "XXXX - A YEAR OF CHALLENGES, OPPORTUNITIES, INNOVATIONS IN ESG"
                                </td>
                            </tr>
                            <tr>
                                <td style="padding-top:18px; line-height: 1.38;">I am pleased to share our <span style="color: #ff1616;"> #(1st, 2nd, etc.)</span> sustainability report; providing insights into our
                                    performance on Environmental, Social and Governance parameters for the Year <span style="color: #ee2926;"> XXX </span>. As the
                                    world becomes more globalized, the need to commit to these key principles is greater than
                                    ever.

                                </td>
                            </tr>
                            <tr>
                                <td style="padding-top:18px; line-height: 1.38;">Despite the pressure on our business, we stayed loyal to our guiding mission: providing our
                                    guests with excellent service, fostering the growth of our employees, giving back to our
                                    community, and acting responsibly toward the environment. Through our new sustainability
                                    roadmap for Year <span style="color: #ee2926;"> XXX </span>, we hope to strengthen our efforts to reduce the impact we and our
                                    business have on the environment around us. We also would like to complement this by
                                    working to create a culture that embraces diversity and embodies inclusion.
                                </td>
                            </tr>
                            <tr>
                                <td style="padding-top:18px; line-height: 1.38;">We at <span style="color: #ee2926;">XYZ (Company Name)</span> always strive for newer opportunities, better initiatives and
                                    achieving those for a better tomorrow.
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td width="125">&nbsp;</td>
                    <td height="400" valign="bottom" style="font-family: 'lato-heavy'; font-size: 16px; font-weight: 700; color: #fcc15e;">
                        KHALID ANIB
                        <br> <br>
                        <span style="color: #fff;">CEO</span>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-8  -->
<table border="0" cellpadding="0" cellspacing="0" align="center">
    <tr>
        <td width="500" height="794" style="background-image: url('<?php echo $filePath; ?>/images/index8-1.jpg'); background-image-resize: 6; padding-left: 43px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td width="410" style="font-family: 'lato-heavy'; font-size: 45px; font-weight: 800; color: #fff;">
                        ABOUT XYZ <br>(COMPANY NAME)
                    </td>
                </tr>
                <tr>
                    <td height="80"></td>
                </tr>
                <tr>
                    <td>
                        <table width="280" border="0" cellpadding="0" cellspacing="0" style="font-family: 'montserrat'; font-size: 16px; font-weight: 500; color: #fff; line-height: 35px;">
                            <tr>
                                <td style="border-bottom: 1px solid #fff;  ">XYZ (Company name) At A Glance</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">History (Brief)</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">Financial Performance</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">Response to Covid-19</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">2022 Goals</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
        <td bgcolor="#abd28c">
            <img src="<?php echo $filePath; ?>/images/index8-2.jpg" alt="right-img" width="624" height="794" />
        </td>
    </tr>
</table>


<!-- index-9  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index9-1.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="100%">
            <table width="465" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" align="center" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff;">XYZ (COMPANY NAME) <br> AT A GLANCE</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="35">&nbsp;</td>
    </tr>
    <tr>
        <td height="519" width="1123" valign="top">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="80">&nbsp;</td>
                    <td width="673">
                        <table border="0" cellpadding="0" cellspacing="0" style="color: #ff1616;">
                            <tr>
                                <td width="155">
                                    <img src="<?php echo $filePath; ?>/images/index9-2.jpg" alt="" width="155" height="60">
                                </td>
                                <td width="175" align="center" style="font-family: 'avenir-lt-std-book'; font-size: 16px; ">Total number of Rooms across all XYZ (Company Name) Hotels</td>
                                <td width="23">&nbsp;</td>
                                <td style=" font-family: 'avenir-lt-std-book'; font-size: 41px;">2500+</td>
                                <td width="100">&nbsp;</td>
                            </tr>
                            <tr>
                                <td colspan="5" height="32">&nbsp;</td>
                            </tr>
                            <tr>
                                <td colspan="5" width="673" height="387" valign="top" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px;">
                                    XYZ (Company Name) is an eminent, renowned hospitality group. Beginning with its grand
                                    inception in 1975, this group has expanded to a well-established hospitality conglomerate in
                                    the UAE serving business travelers and leisure tourists alike for decades.

                                    <br><br>
                                    We are proud that we are one of the most popular Green hotels in Abu Dhabi with a proven
                                    track record of having a happy and wide clientbase across the world. Our locations are
                                    spread across Abu Dhabi, Al Ain, Fujairah, Sharjah and Dubai. Our innovation, sustainable
                                    policies, successful business goals and ethics have enabled us to stand tall amidst all the
                                    competition that has occurred over these decades.
                                    <br><br>
                                    Our expanding hospitality group comprising the icons in leisure and business travel service
                                    providers has performed well in revenues and has delivered responsible tourism and worldclass hospitality services, notwithstanding the impact of Covid 19.
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td width="369">&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-10  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index10-1.jpg'); background-repeat: no-repeat;">
    <tr>
        <td>
            <table height="793" border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td width="138" valign="top" align="right">
                        <table valign="top" border="0" cellpadding="0" cellspacing="0" width="100%" style="font-family: 'avenir-lt-std-book'; font-size: 14px; line-height: 1.5; color: #ff1616;">
                            <tr>
                                <td height="45">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Al Ghazal Transportation Company</td>
                            </tr>
                            <tr>
                                <td height="40">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Sofitel Hotels & <br> Resorts Dubai <br> Jumeirah Beach</td>
                            </tr>
                            <tr>
                                <td height="35">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Address Hotels - <br> Dubai Mall, <br> Dubai Marina <br> and Boulevard</td>
                            </tr>
                            <tr>
                                <td height="30">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Venetian <br>Village</td>
                            </tr>
                            <tr>
                                <td height="60">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Le Meridien <br> Abu Dhabi</td>
                            </tr>
                            <tr>
                                <td height="40">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Al Diar Hotels - <br> Capital, Mina, <br> Dana & Sawa <br> Hotels</td>
                            </tr>
                            <tr>
                                <td height="30">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Vida Downtown, <br>Manzil Downtown</td>
                            </tr>
                        </table>
                    </td>
                    <td style="padding-bottom: 20px;" width="225">
                    </td>
                    <td width="176" valign="top" style="padding-left: 7px;">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" style="font-family: 'avenir-lt-std-book'; font-size: 14px; line-height: 1.5; color: #ff1616;">
                            <tr>
                                <td style="padding-top: 15px;">XYZ(Company Name) Compass ME</td>
                            </tr>
                            <tr>
                                <td height="55">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Sunshine Travels <br> & Tours</td>
                            </tr>
                            <tr>
                                <td height="40">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>The Ritz-Carlton Abu <br> Dhabi Grand Canal, <br> Venetian Village</td>
                            </tr>
                            <tr>
                                <td height="50">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Sheraton Abu Dhabi <br> Hotel and Resort</td>
                            </tr>
                            <tr>
                                <td height="70">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Radisson Blu Hotels and Resorts Abu Dhabi & Al <br> Ain</td>
                            </tr>
                            <tr>
                                <td height="35">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Abu Dhabi <br> Hospitality</td>
                            </tr>
                            <tr>
                                <td height="55">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Park Hyatt <br> Abu Dhabi Hotels & Villas</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
        <td width="580" height="793" valign="top">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="padding-left: 50px; padding-right: 80px; color: #ff1616;">
                <tr>
                    <td colspan="3" height="75">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" width="" style="font-family: 'avenir-lt-std-book'; font-size: 23px; font-weight: 400; ">Abu Dhabi National Hotels Company</td>
                </tr>
                <tr>
                    <td colspan="3" height="75">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" width="" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 1.3;">
                        XYZ (Company Name) owns some of the most reputable and iconic hotels in the Emirate and beyond: The Ritz-Carlton Abu Dhabi, Grand Canal; Park Hyatt Abu Dhabi Hotel and Villas; Sheraton Abu Dhabi Hotel & Resort; Le Meridien Abu Dhabi; Radisson Blu Hotel & Resort Al Ain; Radisson Blu Hotel & Resort Abu Dhabi, Corniche; Sofitel Dubai Jumeirah Beach; Address Boulevard; Address Dubai Mall; Address Dubai Marina; Vida Downtown and Manzil Downtown.
                        <br> <br>
                        XYZ (Company Name) is managing a portfolio of hotels hotel apartments in prime city locations under the umbrella of Al Diar Hotels brand.The group also manages a collection of innovative food and beverage concepts under the umbrella of the Venetian Village, wherein franchises of internationally acclaimed restaurant brands are operated in an exclusive setting within the grounds of The Ritz-Carlton Abu Dhabi, Grand Canal. XYZ (Company Name)’s other hospitality divisions enclose Al Ghazal Transport and XYZ (Company Name) Compass
                    </td>
                </tr>
                <tr>
                    <td colspan="3" height="45">&nbsp;</td>
                </tr>
                <tr>
                    <td align="left">
                        <img src="<?php echo $filePath; ?>/images/index10-3.jpg" alt="index10-3" width="78" height="62">
                    </td>
                    <td width="150" align="center" style="font-family: 'avenir-lt-std-book'; font-size: 18px;">Guests Hosted <br> in 2021 </td>
                    <td align="center" style="font-family: 'avenir-lt-std-roman';  font-weight: 400; font-size: 40px;">1,000,000+</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-11  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index11.jpg'); background-repeat: no-repeat;">
    <tr>
        <td valign="top" style="padding-left: 65px; padding-top: 60px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td width="572" height="26" valign="top" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-bottom: 45px;">
                        Ethics have enabled us to stand tall amidst all the competition that has occurred over these decades.
                    </td>
                </tr>
                <tr>
                    <td width="543" style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c; margin-right: 30px;">XYZ (Company Name) Compass ME</td>
                </tr>
                <tr>
                    <td width="530" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding: 15px 10px 15px 0;">
                        A joint venture between XYZ (Company Name) and the renowned
                        Compass group, XYZ (Company Name) Compass ME is the catering and
                        support services provider delivering very high value to our esteemed
                        clientele through our passion for the culinary art. With over 22,000
                        employees, XYZ (Company Name) compass is known for delivering fine
                        service to thousands of customers each day. Food services, cleaning &
                        housekeeping, camp management, manpower supply services, and
                        procurement services are their specialty.

                    </td>
                </tr>
            </table>
        </td>
        <td width="480"></td>
    </tr>
    <tr>
        <td colspan="2" height="182">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2" style="padding-top: 40px; padding-bottom: 80px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td width="560"></td>
                    <td width="565" style="padding-right: 55px;">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c;">Al Diar Hotels</td>
                            </tr>
                            <tr>
                                <td style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px;">
                                    Al Diar is a collection of 2-3 star hotel and hotel apartments in Abu
                                    Dhabi. Innovative Fine dining and rejuvenation are key characteristics
                                    of Al Diar. The group has taken initiatives to increase the total hours
                                    of Occupational Health & Safety training offered to employees.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-12  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index12.jpg'); background-repeat: no-repeat;">
    <tr>
        <td colspan="2" style="padding-top: 83px; padding-bottom: 30px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td width="562"></td>
                    <td width="558" style=" padding-right: 50px;">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c;">Sunshine Travels & Tours</td>
                            </tr>
                            <tr>
                                <td style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px; padding-right: 20px;">
                                    Sunshine is a renowned travel and tours services provider in XYZ
                                    (Company Name). Ranging from flight & hotel bookings, limo
                                    services, tour packages, airport meet & assist, transfers & transport
                                    up to visa processing, a wide gamut of services is on the offer. With
                                    more than 2700 registered rooms and executive suites and
                                    impeccable adherence to environmental needs, Sunshine leads the
                                    group with a responsible track record of being a green business.

                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2" height="182">&nbsp;</td>
    </tr>
    <tr>
        <td width="600" height="302" valign="top" style="padding-top: 5px; padding-left: 95px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c;">Al Ghazal Transportation Company</td>
                </tr>
                <tr>
                    <td style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px;">
                        Al Ghazal started the business over 30 years ago. The range of
                        services includes Bus transportation, vehicle rentals, leasing, VIP
                        limos, maintenance and car repair services throughout the country. As
                        an organization, they are committed to eco-friendly initiatives, in
                        addition, to providing their guests with a world-class transportation
                        service.


                    </td>
                </tr>
            </table>
        </td>
        <td width="522"></td>
    </tr>
</table>

<!-- index-13  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index13.jpg'); background-repeat: no-repeat;">
    <tr>
        <td valign="top" width="643" style="padding-left: 65px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td height="80">&nbsp;</td>
                </tr>
                <tr>
                    <td width="543" style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c; margin-right: 30px;">The Ritz-Carlton Abu Dhabi Grand Canal</td>
                </tr>
                <tr>
                    <td width="543" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-right: 15px;  padding-top: 15px;">
                        Ritz Carlton is a premier luxury hospitality provider where Arabic hospitality
                        and opulence are synonymous. Opera performances, live entertainment
                        dining, club lounge, expansive outdoor pools, global cuisine, Grand Canal,
                        Spa treatments, Ritz-Carlton Destination club, Ritz Kids Program, grand
                        destination for weddings are some good mention however as a key eco
                        partner in XYZ (Company Name), Ritz Carlton also launches creative,
                        innovative activities for that leave a positive impact on people and the
                        environment.

                    </td>
                </tr>
            </table>
        </td>
        <td width="480"></td>
    </tr>
    <tr>
        <td colspan="2" height="255">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td width="560"></td>
                    <td width="565" style="padding-right: 55px;">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c;">Sofitel Hotels & Resorts Dubai Jumeirah Beach</td>
                            </tr>
                            <tr>
                                <td style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px; padding-bottom: 22px; ">
                                    Sofitel, located in Palm Jumeirah is a luxury 5-star beach resort with
                                    accommodation options including luxury room, classic room, Opera
                                    suite, Prestige suite, beach villa, bedroom apartment, etc. Sofitel is an
                                    active participant in ESG events and initiatives. Observing Environment
                                    Day by showcasing nurseries that were cultivated by our ambassadors
                                    using food waste as fertilizer, participating in desert cleaning drives are
                                    noteworthy achievements for an organization that is part of the
                                    “Responsible business” group.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-14  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index14.jpg'); background-repeat: no-repeat;">
    <tr>
        <td colspan="2" style="padding-bottom: 30px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td width="562">&nbsp;</td>
                    <td width="558" style=" padding-right: 50px;">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td height="83">&nbsp;</td>
                            </tr>
                            <tr>
                                <td style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c;">Address Hotel Dubai Marina</td>
                            </tr>
                            <tr>
                                <td style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px; padding-right: 20px;">
                                    Much like Dubai Marina, the Address Hotels Dubai Marina is also a
                                    landmark provider of a superior class of hospitality. The Hotel
                                    ensures the safety and wellness of tourists and employees alike and
                                    is compliant with the protocols of Covid 19. With 450+ rooms and
                                    suites, it has a fair share of green cover. With Covid 19 slowly
                                    declining, the hospitality group is geared up for the surge in
                                    business.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2" height="182">&nbsp;</td>
    </tr>
    <tr>
        <td width="600" height="302" valign="top" style="padding-top: 5px; padding-left: 95px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c;">Address Hotel Boulevard</td>
                </tr>
                <tr>
                    <td style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px;">
                        In Dubai, Address Hotel Boulevard is a flagship identity. While the
                        business has had stellar financial performance in 2021, the hotel has
                        excelled in contributing and hosting plenty of events as part of Green
                        Key program. It has been part of the Dubai Can initiative and its CSR
                        program Pearl Pledge distinguishes Boulevard for its contributions as
                        an active member in environment-friendly businesses in the world.
                        They have always embraced the pandemic protocols with utmost care
                        and accountability towards their people, guests and stakeholders.
                    </td>
                </tr>
            </table>
        </td>
        <td width="522"></td>
    </tr>
</table>


<!-- index-15  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index15.jpg'); background-repeat: no-repeat;">
    <tr>
        <td valign="top" width="560" style="padding-left: 80px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td height="80">&nbsp;</td>
                </tr>
                <tr>
                    <td width="450" style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c;">Park Hyatt Abu Dhabi Hotels & Villas</td>
                </tr>
                <tr>
                    <td width="450" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px;">
                        As a premier hotel in Abu Dhabi, Park Hyatt adheres to all the
                        Government initiatives and has succeeded in rising to the need of
                        the hour during Covid-19 crisis. Employees were duly encouraged in
                        fulfilling endeavours such as blood donation drive, observing of
                        international housekeeping week, nurdle hunt, life saving training
                        for colleagues, art exhibition, fire safety training and breast cancer
                        awareness campaigns.
                    </td>
                </tr>
            </table>
        </td>
        <td width="562"></td>
    </tr>
    <tr>
        <td colspan="2" height="232">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td width="560"></td>
                    <td width="565" height="285" style="padding-right: 55px;">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c;">Vida Downtown</td>
                            </tr>
                            <tr>
                                <td style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px; padding-bottom: 22px; ">
                                    Vida Downtown serves the local and international markets in boutique
                                    destinations. The year 2021 had witnessed a good influx of guests and
                                    the hotel has been ably equipped to handle the surge which was much
                                    higher than the footfall of the previous year. As part of occupational
                                    health & safety management policy, annual health screening is
                                    performed for all employees and is included as part of the HR
                                    recruitment process as well.

                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-16  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index16.jpg'); background-repeat: no-repeat;">
    <tr>
        <td valign="top" width="643" style="padding-left: 65px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td colspan="2" height="57">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c; margin-right: 30px;">Address Hotel Dubai Mall</td>
                    <td width="50">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-right: 15px;  padding-top: 15px;">
                        Address Dubai Mall, with a staff headcount of 100 in 2021, has
                        hosted thousands of guests in 2021. With a 15-min walk from Burj
                        Khalifa, it offers a wide range of luxury suites to choose from. With
                        regard to work-related injuries and safety incidents, the hotel has
                        accounted for less than 5 injuries in 2021. Non-discrimination and
                        human rights parameters are embedded in the Company
                        Standards of Conduct Policy. With a healthy occupancy rate and a
                        fair gender equality ratio in the workforce this organization has
                        been an important part of the XYZ (Company Name) group.
                    </td>
                    <td width="50">&nbsp;</td>
                </tr>
            </table>
        </td>
        <td width="480"></td>
    </tr>
    <tr>
        <td colspan="2" height="212">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td width="570"></td>
                    <td width="575" height="285" style="padding-right: 55px;">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c;">Sheraton Abu Dhabi Hotel and Resort</td>
                            </tr>
                            <tr>
                                <td style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px; padding-bottom: 22px; ">
                                    A well-known beach resort in XYZ (Company Name) group, Sheraton
                                    Abu Dhabi is a center for entertainment, fitness, business and leisure
                                    visitors. The staff teams are well versed in Covid-19 measures and
                                    hygiene and cleanliness standards. Screening and sanitization of sites
                                    and operational excellence go hand in hand in this partner organization.
                                    Having sustainable supply chains in place makes for a perfect example of
                                    sustainable business models.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-17  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index17.jpg'); background-repeat: no-repeat;">
    <tr>
        <td colspan="2" style="padding-bottom: 30px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td width="562">&nbsp;</td>
                    <td width="558" style=" padding-right: 50px;">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td height="122">&nbsp;</td>
                            </tr>
                            <tr>
                                <td style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-right: 20px;">
                                    Radisson Blu Al Ain conducted a blood donation drive which drew a
                                    good number of people to donate blood. Radisson Blu Clean-up
                                    Drive has also been a success. They also assess indoor air quality
                                    and water quality through reputed laboratories and quality auditors.
                                    Another interesting aspect of the eco-drive at Radisson Blu Al Ain is
                                    that 50% is the total area of green cover vs total property area. This
                                    is a very tough balance to achieve.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2" height="200">&nbsp;</td>
    </tr>
    <tr>
        <td width="620" height="302" valign="top" style="padding-top: 5px; padding-left: 95px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c;">Radisson Blu Hotels and Resorts Abu Dhabi & Al Ain</td>
                </tr>
                <tr>
                    <td style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px;">
                        Cruelty-free hospitality is to be adopted when engaging in green
                        business. Radisson Blu Abu Dhabi upholds this sentiment. The strategy is
                        built around sustainable tourism, hence the opportunities offered are
                        carefully chosen. Recovery from Covid's impact saw the latter half of
                        2021 emerging as the transformation crossroads for our industry on the
                        whole. People, community and planet are the main drivers of any
                        sustainability goal and it was evident in 2021 as well. They are part of the
                        Sustainable Hospitality Alliance, One Planet Network and partner with
                        ECPAT-USA. Radisson Abu Dhabi has also been a UN Global Compact
                        Signatory.
                    </td>
                </tr>
            </table>
        </td>
        <td width="522"></td>
    </tr>
</table>


<!-- index-18  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index18.jpg'); background-repeat: no-repeat;">
    <tr>
        <td valign="top" width="665" style="padding-left: 65px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td height="55">&nbsp;</td>
                </tr>
                <tr>
                    <td width="" style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c; margin-right: 30px;">Le Meridien Abu Dhabi</td>
                </tr>
                <tr>
                    <td width="" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px;  padding-top: 15px;">
                        Le Meridien is a highly dynamic and agile partner organization in the XYZ
                        (Company Name) group, for the plethora of initiatives it participates in. The whole
                        of 2021 was an eventful year as there was a slew of campaigns and events which Le
                        Meridien participated in as part of its CSR and ESG objectives. In the Can collection
                        Day drive, LM collected 35 kg of aluminum cans, was awarded the Go Safe
                        certificate and was proudly honored with Green Key certification by International
                        Environmental Award. They also conducted Chemical safety training & drill,
                        environment & safety week recycling art competition and cake cutting for staff,
                        environment hygiene & safety training, collected 346 kg of paper as part of
                        Recycling Campaign 2021, tree planting campaign. They encourage zero waste in
                        our culinary practices and competition on the same was held for Chefs.

                    </td>
                </tr>
            </table>
        </td>
        <td width="480"></td>
    </tr>
    <tr>
        <td colspan="2" height="200">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td width="520"></td>
                    <td width="105" style="padding-right: 55px;">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c;">Abu Dhabi Hospitality</td>
                            </tr>
                            <tr>
                                <td style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px; padding-bottom: 30px; ">
                                    The hospitality domain is an eternally busy and highly competitive one. Hence
                                    to stay in the list, one needs to be up-to-date with newer technologies and
                                    most importantly be customer-centric. This wing is a prestigious part that
                                    shares the group’s core ethics and sentiment regarding responsible business,
                                    to the extent that even the Supplier and vendor collaboration is based on an
                                    agreed Code of Conduct and a minimum of 95% compliance to the code of
                                    Conduct is mandatory. Warm Arabian hospitality coupled with eco-centric
                                    goals makes Abu Dhabi hospitality a key player in our group for hospitality
                                    products and solutions.

                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-19  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index19.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="100%">
            <table width="465" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left: 30px;">FINANCIAL PERFORMANCE</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="561" height="552" valign="top" style="padding-left: 65px; padding-right: 15px;">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="3" height="105">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px;">
                        Despite Covid-19, our hospitality group performed well, with
                        fair figures on all financial parameters.
                    </td>
                </tr>
                <tr>
                    <td colspan="3" height="30">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px;">
                        Net profits at XYZ (Company Name) stands at <span style="font-family: 'Lato-heavy'; font-size: 20px;"> 273 Million AED</span>
                    </td>
                </tr>
                <tr>
                    <td colspan="3" height="100">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c;">Operating Revenue -</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 18px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index19-4.jpg" width="107" height="104" alt="" style="padding: 20px 0;"><br>
                        1.40 Billion AED
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 18px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index19-5.jpg" width="86" height="104" alt="" style="padding: 20px 0;"><br>
                        0.87 Billion AED
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 18px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index19-6.jpg" width="86" height="108" alt="" style="padding: 20px 0;"><br>
                        1.08 Billion AED
                    </td>
                </tr>
            </table>
        </td>
        <td width="561" height="552" valign="top" style="padding: 16px 65px 0 15px;">
            <table table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="3" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c;">Profits</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 18px; text-align: center; padding-right: 15px;">
                        <img src="<?php echo $filePath; ?>/images/index19-1.jpg" width="100" height="100" alt="" style="padding: 20px 0;"><br>
                        253 Million AED
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 18px; text-align: center; padding-right: 15px;">
                        <img src="<?php echo $filePath; ?>/images/index19-2.jpg" width="100" height="100" alt="" style="padding: 20px 0;"><br>
                        (720 Million) AED
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 18px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index19-3.jpg" width="100" height="100" alt="" style="padding: 20px 0;"><br>
                        273 Million AED
                    </td>
                </tr>
                <tr>
                    <td colspan="3" height="100">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c;">Total Assets</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 18px; text-align: center; padding-right: 15px; padding-top: 9px;">
                        <img src="<?php echo $filePath; ?>/images/index19-7.jpg" width="71" height="100" alt="" style="padding: 20px 0;"><br>
                        11.44 Billion AED
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 18px; text-align: center; padding-right: 15px;padding-top: 9px;">
                        <img src="<?php echo $filePath; ?>/images/index19-8.jpg" width="71" height="100" alt="" style="padding: 20px 0;"><br>
                        9.76 Billion AED
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 18px; text-align: center;padding-top: 9px;">
                        <img src="<?php echo $filePath; ?>/images/index19-9.jpg" width="71" height="100" alt="" style="padding: 20px 0;"><br>
                        9.83 Billion AED
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-20  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index20.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="100%">
            <table width="465" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left:40px;">RESPONSE TO <br>
                        COVID-19</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="45">&nbsp;</td>
    </tr>
    <tr>
        <td height="509" width="1123" valign="top">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="80">&nbsp;</td>
                    <td width="617" style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align:justify; line-height: 22px;">
                        Covid-19 wave across the globe has been a profoundly challenging crisis, particularly
                        with the urgent need to catapult the safety standards in the hospitality industry to
                        bring about newer, safer and highly advanced Covid-proof security protocols for the
                        benefit of our guests/clients/customers and employees. It has been a learning and
                        great chance to sight the morale of the entourage as they rose to the circumstances
                        and united with the changing times to adapt themselves to the need of the hour. We
                        would like to thank our people for their courage, cooperation and immense support
                        during these times.
                        <br><br>
                        Covid 19 measures have been implemented for all guests and staff since the onset of
                        the pandemic. Free PCRs were conducted for all workers and face masks were
                        distributed. All Covid-19 protocols prescribed by the government and health
                        authorities have been in place and are duly quality-checked.
                        <br><br>
                        <span style="font-family: 'lato-heavy'; font-weight: 500;">
                            "We have been appreciated by Schlumberger for Covid 19 Support. XYZ (Company
                            Name) continues to deliver pandemic-oriented support practices, amenities for a safe,
                            hygienic and peaceful tourism experience at our group. "
                        </span>

                    </td>
                    <td width="369">&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-21  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index21.jpg'); background-repeat: no-repeat;">
    <tr>
        <td width="564" height="794">&nbsp;</td>
        <td width="558" height="794" valign="top">
            <table border="0" valign="top" cellpadding="0" cellspacing="0" width="100%" style="padding-right: 145px;">
                <tr>
                    <td height="80">&nbsp;</td>
                </tr>
                <tr>
                    <td style="font-family: 'avenir-black'; font-size: 16px; color: #abd28c; ">The following steps were taken for enhanced hygiene
                        in our hotels:
                    </td>
                </tr>
                <tr>
                    <td height="30">&nbsp;</td>
                </tr>
                <tr>
                    <td style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 1.3;">
                        <ol>
                            <li> Implemented guidelines on chemicals and equipment
                                to be used that are effective against viruses.</li>
                            <br>
                            <li>Increased the frequency of cleaning and disinfection at
                                high-volume areas and regularly touched surfaces. These
                                include the counters at front desk, elevators, bathrooms
                                and room keys.</li>
                            <br>
                            <li>Cleaning and disinfecting protocols are implemented
                                to sanitize rooms after guests depart and before the next
                                guest arrives.</li>
                            <br>
                            <li> Increased frequency of cleaning was done, where hotel
                                employees work behind the scenes.</li>
                            <br>
                            <li>Increased staff health, safety and knowledge efforts,
                                including hand hygiene protocols and provided specific
                                COVID-19 related trainings.</li>
                            <br>
                            <li>Introduced measures to minimize contact and
                                reinforce social distancing</li>
                            <br>
                            <li>Personal Protective Equipment (PPE): Staff members
                                are instructed to wear PPE (e.g., face coverings, gloves,
                                etc.) based on the activities they are performing and
                                based on direction by the local authorities.</li>
                            <br>
                        </ol>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-22  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index22.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80" width="1124">&nbsp;</td>
    </tr>
    <tr>
        <td>
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="460">
                        <table width="455" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                            <tr>
                                <td height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left:60px;">2022 PLANS</td>
                            </tr>
                        </table>
                    </td>
                    <td colspan="2" width="83">&nbsp;</td>
                    <td width="470" align="center" style="font-family: 'avenir-black'; font-size: 16px; color: #abd28c; text-align:justify; line-height: 22px;">
                        We set our 2022 plans with an aim to bring more sustainable
                        operations and services to our guests, targeting performance
                        enhancement on all ESG parameters.
                    </td>
                    <td width="117">&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="155">&nbsp;</td>
    </tr>
    <tr>
        <td>
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="70">&nbsp;</td>
                    <td width="230" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align: center; line-height: 22px; padding-right: 15px;">
                        Community Investment &
                        contribution to the UAE
                        economy’s growth
                    </td>
                    <td width="230" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align: center; line-height: 22px; padding-right: 15px;">
                        Establish air quality, water
                        quality, emission control
                        progress
                    </td>
                    <td width="230" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align: center; line-height: 22px; padding-right: 15px;">
                        Participate in governmentled earth-friendly
                        initiatives
                    </td>
                    <td width="230" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align: center; line-height: 22px;">
                        Use of social media platform to
                        address larger audiences to
                        drive environment-safety related
                        campaigns
                    </td>
                    <td width="157">&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="120">&nbsp;</td>
    </tr>
    <tr>
        <td valign="top">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="180">&nbsp;</td>
                    <td width="230" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align: center; line-height: 22px; padding-right: 20px;">
                        Prioritize the safety and well being of guests and our
                        employees.
                    </td>
                    <td width="220" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align: center; line-height: 22px; padding-right: 20px;">
                        Introduction of programs
                        for improving skills training
                        among employees and
                        transition assistance
                        programs
                    </td>
                    <td width="220" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align: center; line-height: 22px; padding-right: 20px;">
                        Reduce landfills by
                        controlling food and
                        water waste
                    </td>
                    <td width="220" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align: center; line-height: 22px;">
                        Drive anti-corruption
                        behaviour and preserve
                        human rights through
                        Standards of Conduct
                        policy
                    </td>
                    <td width="100">&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="110">&nbsp;</td>
    </tr>
</table>


<!-- index-23  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index23.jpg'); background-image-resize: 6;">
    <tr>
        <td width="500" height="794" style=" padding-left: 53px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td width="444" style="font-family: 'lato-heavy'; font-size: 45px; font-weight: 800; color: #fff;">
                        ENVIRONMENTAL STEWARDSHIP
                    </td>
                </tr>
                <tr>
                    <td height="42">&nbsp;</td>
                </tr>
                <tr>
                    <td>
                        <table width="280" border="0" cellpadding="0" cellspacing="0" style="font-family: 'montserrat'; font-size: 16px; font-weight: 500; color: #fff; line-height: 35px;">
                            <tr>
                                <td style="border-bottom: 1px solid #fff;  ">Environmental Initiatives</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">Energy & Water Consumption</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">Waste Management</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">GHG Emissions</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">2022 Goals</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
        <td width="622">
        </td>
    </tr>
</table>


<!-- index-24  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index24.jpg'); background-image-resize: 6;">
    <tr>
        <td width="372" height="794">
        </td>
        <td valign="top" width="670" height="794">
            <table valign="top" border="0" cellpadding="0" cellspacing="0" width="670">
                <tr>
                    <td colspan="2" height="180">&nbsp;</td>
                </tr>
                <tr>
                    <td width="65">&nbsp;</td>
                    <td style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align:justify; line-height: 22px;">
                        A healthy and thriving environment is crucial. The measures to protect it, then, are
                        extremely important to us. We promise to do our part to lessen pollution, promote
                        environmentally friendly practices, offset carbon emissions, and enhance air & water
                        quality.
                        <br><br>
                        As our natural resources are finite, it is crucial we put in sufficient thought and effort
                        into preserving them. At Company XYZ, here are some steps we take -

                    </td>
                </tr>
                <tr>
                    <td colspan="2" height="50" style="border-bottom: 1px solid #000;">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="2" style="padding: 30px 0; border-bottom: 1px solid #000;">
                        <table border="0" cellpadding="0" cellspacing="0">
                            <tr>
                                <td width="250">
                                    <table width="250" border="0" cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td style="font-family: 'avenir-lt-std-book'; font-size: 18px; text-align: center; line-height: 22px;">Total Green Cover Across All XYZ (Company Name) <br> Hotels</td>
                                        </tr>
                                        <tr>
                                            <td style="font-family: 'avenir-lt-std-book'; font-size: 41px; text-align: center;">188128 SQM</td>
                                        </tr>
                                    </table>
                                </td>
                                <td width="270" align="center">
                                    <img src="<?php echo $filePath; ?>/images/index24_1.jpg" alt="" width="115" height="113">
                                </td>
                                <td>
                                    <table border="0" cellpadding="0" cellspacing="0" style="font-family: 'avenir-lt-std-book'; font-size: 18px; text-align: center; line-height: 22px;">
                                        <tr>
                                            <td>Equivalent to</td>
                                        </tr>
                                        <tr>
                                            <td style="font-size: 41px; padding: 10px 0;">26</td>
                                        </tr>
                                        <tr>
                                            <td>Football fields</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="padding: 30px 0;">
                        <table border="0" cellpadding="0" cellspacing="0">
                            <tr>
                                <td width="250" style="font-family: 'avenir-lt-std-book'; font-size: 18px; text-align: center; line-height: 22px; padding: 0 15px;">
                                    Total Amount spent on climate-related issues in last 3 years
                                </td>
                                <td width="270" align="center">
                                    <img src="<?php echo $filePath; ?>/images/index24_2.jpg" alt="" width="115" height="113">
                                </td>
                                <td style="font-family: 'avenir-lt-std-book'; font-size: 41px; text-align: center; line-height: 22px;">450,000+
                                    <br>
                                    <br> AED
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
        <td width="80">&nbsp;</td>
    </tr>
</table>


<!-- index-25  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index25.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80" width="1124">&nbsp;</td>
    </tr>
    <tr>
        <td>
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="460">
                        <table width="455" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                            <tr>
                                <td height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left:60px;">ENVIRONMENTAL INITIATIVES</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="155">&nbsp;</td>
    </tr>
    <tr>
        <td height="110">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="140">&nbsp;</td>
                    <td width="232" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 15px;">
                        Liaise with partners to
                        conduct sustainable processes
                        to expand the current
                        initiatives

                    </td>
                    <td width="240" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 15px;">
                        Enhance our guests’ experience
                        through engagement and
                        driving awareness on
                        environmental practices.

                    </td>
                    <td width="220" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 15px;">
                        Eradicate one time use
                        plastic items from our
                        bathrooms.
                    </td>
                    <td width="255" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px;">
                        Achieve our goals with a 15 %
                        reduction in energy usage, a 15 %
                        reduction in water consumption and 60
                        % of waste diverted away from landfill
                        by 2022 vs 2019
                    </td>
                    <td width="157">&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="130">&nbsp;</td>
    </tr>
    <tr>
        <td valign="top">
            <table align="center" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="270" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 20px;">
                        Dubai Can Initiative: say NO to
                        single-use plastic bottles.
                        We're kickstarting the
                        movement and will be soon
                        switching to reusable bottles
                        and filtered water.

                    </td>
                    <td width="250" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 30px;">
                        Have a unique brand-specific
                        sustainability action plan for
                        each hotel and asset.
                    </td>
                    <td width="180" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px;">
                        Establish partnership with
                        UAE Food Bank to
                        minimize food waste
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="135">&nbsp;</td>
    </tr>
</table>


<!-- index-26  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index26.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="100%">
            <table width="465" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left:40px;">RESPONSE TO <br>
                        COVID-19</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="50">&nbsp;</td>
    </tr>
    <tr>
        <td height="504" width="1123" valign="top" style="padding-left: 80px;">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="2" width="515" style="font-family: 'avenir-black'; font-size: 16px; text-align: center; line-height: 22px;">
                        Practicing within organizations is not always sufficient to make a
                        huge impact. Stepping out of the comfort zone and going outdoors
                        and setting an example is what makes our case studies special.
                    </td>
                </tr>
                <tr>
                    <td colspan="2" height="50">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-bottom: 15px; line-height: 25px;">SOFITEL HOTELS & RESORTS DUBAI JUMEIRAH
                        BEACH</td>
                    <td width="45">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">
                        <ul>
                            <li>CS Vydyanathan collected 53 kgs in the can collection drive
                                hosted by Emirates Environmental Group (EEG)</li>
                            <br>
                            <li>Clean Up UAE – Desert cleaning drive</li>
                        </ul>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-27  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index27.jpg'); background-image-resize: 6;">
    <tr>
        <td width="1122" height="794" align="center">
            <table width="475" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px;">SOFITEL HOTELS & RESORTS DUBAI
                        JUMEIRAH BEACH</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">
                        <ul>
                            <li>Waste management by segregating waste for biodegradable,
                                hazardous waste</li><br>
                            <li>346 kg of paper collected in recycling campaign</li><br>
                            <li>Chemical Safety & training sessions</li><br>
                            <li>Can collection</li><br>
                            <li>Green Key Certificate by International Environmental Award</li><br>
                        </ul>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-28  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index28.jpg'); background-image-resize: 6;">
    <tr>
        <td width="1122" height="794" align="center">
            <table width="475" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px;">SOFITEL HOTELS & RESORTS DUBAI
                        JUMEIRAH BEACH</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">
                        <ul>
                            <li>Zero waste MEA competition for chefs</li><br>
                            <li>Tree planting campaign</li><br>
                            <li>Environment & safety week –recycling art competition</li><br>
                            <li>Covid Precaution measures</li><br>
                        </ul>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-29  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index29.jpg'); background-image-resize: 6; background-repeat:no-repeat;">
    <tr>
        <td width="570" align="center">
            <table border="0" cellpadding="0" cellspacing="0" width="350">
                <tr>
                    <td height="328">&nbsp;</td>
                </tr>
                <tr>
                    <td align="left" valign="middle" height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff;">ENERGY & WATER CONSUMPTION</td>
                </tr>
                <tr>
                    <td valign="top" height="326" style="font-family: 'avenir-lt-std-roman'; line-height: 1.4; font-size: 16px; text-align: justify; color: #fff; padding-top: 15px;">Recycling energy or water is as important as
                        controlling the usage of both. There is a high
                        chance of wastage or excess use, if consumed
                        without a check. Our water and energy
                        consumption records are monitored on a yearly
                        basis. It has been one of our concrete efforts to
                        measure the results, achieving our sustainability
                        goals. Most of our electricity consumption is
                        from grid elecricity.
                    </td>
                </tr>
            </table>
        </td>
        <td width="242" height="793">&nbsp;</td>
        <td width="210" height="793">
            <table border="0" cellpadding="0" cellspacing="0" width="205" style="font-family: 'avenir-lt-std-book'; line-height: 1.4; text-align: center; font-size: 16px; color: #fff;">
                <tr>
                    <td>Total electricity consumption stands at</td>
                </tr>
                <tr>
                    <td style="font-family: 'avenir-lt-std-roman'; font-size: 24px;">0.11 KW/AED</td>
                </tr>
                <tr>
                    <td>of revenue earned</td>
                </tr>
                <tr>
                    <td height="90">&nbsp;</td>
                </tr>
                <tr>
                    <td>Total fuel consumption stands at</td>
                </tr>
                <tr>
                    <td style="font-family: 'avenir-lt-std-roman'; font-size: 24px; padding: 3px 0;">5.53 Liters/AED</td>
                </tr>
                <tr>
                    <td>of revenue earned.</td>
                </tr>
                <tr>
                    <td height="90">&nbsp;</td>
                </tr>
                <tr>
                    <td>Total LPG/CNG consumption stands at</td>
                </tr>
                <tr>
                    <td style="font-family: 'avenir-lt-std-roman'; font-size: 24px; padding: 3px 0;">0.27 Litres/AED</td>
                </tr>
                <tr>
                    <td>of revenue earned.</td>
                </tr>
                <tr>
                    <td height="90">&nbsp;</td>
                </tr>
                <tr>
                    <td>Total water consumption stands at</td>
                </tr>
                <tr>
                    <td style="font-family: 'avenir-lt-std-roman'; font-size: 24px; padding: 3px 0;">1.06 Litres/AED</td>
                </tr>
                <tr>
                    <td>of revenue earned.</td>
                </tr>
            </table>
        </td>
        <td width="100">&nbsp;</td>
    </tr>
</table>


<!-- index-30  -->
<table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index30.jpg'); background-repeat: no-repeat;">
    <tr>
        <td colspan="9" height="95">&nbsp;</td>
    </tr>
    <tr>
        <td width="70">&nbsp;</td>
        <td height="240" width="440" align="center">
            <table width="100%" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="3" align="left" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c; padding-bottom: 5px;">Total Electricity Consumption -</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #4677bb;">2019</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #fcc15e;">2020</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #abd28c;">2021</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index30_1.png" width="91" height="90" alt="" style="padding: 20px 0;"><br>
                        145,996.16 MW
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index30_2.png" width="91" height="90" alt="" style="padding: 20px 0;"><br>
                        112,069.17 MW
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index30_3.png" width="91" height="90" alt="" style="padding: 20px 0;"><br>
                        124,106.84 MW
                    </td>
                </tr>
            </table>
        </td>
        <td width="70">&nbsp;</td>
        <td width="440" align="center">
            <table width="100%" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="3" align="left" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c; padding-bottom: 5px;">Operating Revenue -</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #4677bb;">2019</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #fcc15e;">2020</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #abd28c;">2021</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index30_4.png" width="89" height="86" alt="" style="padding: 20px 0;"><br>
                        10431.22 <br>Megaliters
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index30_5.png" width="89" height="86" alt="" style="padding: 20px 0;"><br>
                        6336.39 <br>Megaliters
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index30_6.png" width="89" height="86" alt="" style="padding: 20px 0;"><br>
                        5979.45 <br>Megaliters
                    </td>
                </tr>
            </table>
        </td>
        <td width="70">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="9" height="65">&nbsp;</td>
    </tr>
    <tr>
        <td width="1123" height="394" valign="top" align="center" colspan="9">
            <table table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="3" align="left" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c; padding-bottom: 5px;">Total LPG/CNG Consumption (Inside the organization) -</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #4677bb;">2019</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #fcc15e;">2020</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #abd28c;">2021</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center; padding-right: 15px;">
                        <img src="<?php echo $filePath; ?>/images/index30_7.png" width="51" height="90" alt="" style="padding: 20px 0;"><br>
                        1146636.94 <br>Cubic meters
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center; padding-right: 15px;">
                        <img src="<?php echo $filePath; ?>/images/index30_8.png" width="51" height="90" alt="" style="padding: 20px 0;"><br>
                        240653.85 <br>Cubic meters
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index30_9.png" width="51" height="90" alt="" style="padding: 20px 0;"><br>
                        300005.93 <br>Cubic meters
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-31  -->
<table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index31.jpg'); background-repeat: no-repeat;">
    <tr>
        <td colspan="9" height="185">&nbsp;</td>
    </tr>
    <tr>
        <td width="70">&nbsp;</td>
        <td height="608" width="440" align="center" valign="top">
            <table width="100%" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="3" align="left" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c; padding-bottom: 5px;">Total Water Consumption -</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #4677bb;">2019</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #fcc15e;">2020</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #abd28c;">2021</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index31_1.png" width="58" height="79" alt="" style="padding: 20px 0;"><br>
                        1306.499 <br>Megaliters
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index31_2.png" width="58" height="79" alt="" style="padding: 20px 0;"><br>
                        1030.85 <br>Megaliters
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index31_3.png" width="58" height="79" alt="" style="padding: 20px 0;"><br>
                        1153.03 <br>Megaliters
                    </td>
                </tr>
            </table>
        </td>
        <td width="70">&nbsp;</td>
        <td width="440" align="center" valign="top">
            <table width="100%" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="3" align="left" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c; padding-bottom: 5px;">Total Amount of Water Recycled</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #4677bb;">2019</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #fcc15e;">2020</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #abd28c;">2021</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index31_4.png" width="85" height="90" alt="" style="padding: 20px 0;"><br>
                        14.801 <br>Megaliters
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index31_5.png" width="85" height="90" alt="" style="padding: 20px 0;"><br>
                        11.438 <br>Megaliters
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index31_6.png" width="85" height="90" alt="" style="padding: 20px 0;"><br>
                        29.375 <br>Megaliters
                    </td>
                </tr>
            </table>
        </td>
        <td width="70">&nbsp;</td>
    </tr>
</table>


<!-- index-32  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" width="100%" height="100%" style="background-image: url('<?php echo $filePath; ?>/images/index32.jpg'); background-image-resize: 6; background-repeat:no-repeat;">
    <tr>
        <td width="570" height="794" align="center">
            <table border="0" cellpadding="0" cellspacing="0" width="350" height="794">
                <tr>
                    <td height="328">&nbsp;</td>
                </tr>
                <tr>
                    <td align="left" valign="middle" height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff;">WASTE MANAGEMENT</td>
                </tr>
                <tr>
                    <td valign="top" height="326" style="font-family: 'avenir-lt-std-roman'; line-height: 1.4; font-size: 16px; text-align: justify; color: #fff; padding-top: 15px;">
                        "Waste is nothing but a thing in a wrong place."
                        <br><br>
                        Waste management is key to avoid
                        environmental pollution and to reduce landfills.
                        For us, efficient disposal methods and recycling
                        of waste, work in resonance with segregation
                        and sorting of waste, resulting in an efficient
                        waste management.
                    </td>
                </tr>
            </table>
        </td>
        <td width="154" height="794">&nbsp;</td>
        <td width="333" height="794" valign="top">
            <table valign="top" border="0" cellpadding="0" cellspacing="0" width="333" height="794" style="font-family: 'lato-heavy'; font-size: 20px; line-height: 1.4; padding-top: 45px; text-align: center; color: #fff;">
                <tr>
                    <td align="left" style=" font-family: 'lato-regular'; font-size: 16px; padding-bottom: 4px; border-bottom: 1px solid #fff;">Total Amount of Waste Generated</td>
                </tr>
                <tr>
                    <td style="color: #4677bb; padding-top: 20px;">2019</td>
                </tr>
                <tr>
                    <td width="84" height="89">
                        <img src="<?php echo $filePath; ?>/images/index31_4.png" width="84" height="89" alt="" style="padding: 10px 0;"><br>
                    </td>
                </tr>
                <tr>
                    <td style="border-bottom: 1px solid #fff; padding-bottom: 20px;">259,174 <br>Tons</td>
                </tr>
                <tr>
                    <td style="color: #fcc15e; padding-top: 20px;">2020</td>
                </tr>
                <tr>
                    <td width="84" height="89">
                        <img src="<?php echo $filePath; ?>/images/index31_5.png" width="84" height="89" alt="" style="padding: 10px 0;"><br>
                    </td>
                </tr>
                <tr>
                    <td style="border-bottom: 1px solid #fff; padding-bottom: 20px;">176,725 <br>Tons</td>
                </tr>
                <tr>
                    <td style="color: #abd28c; padding-top: 20px;">2021</td>
                </tr>
                <tr>
                    <td width="84" height="89">
                        <img src="<?php echo $filePath; ?>/images/index31_6.png" width="84" height="89" alt="" style="padding: 10px 0;"><br>
                    </td>
                </tr>
                <tr>
                    <td>246,555 <br>Tons</td>
                </tr>
            </table>
        </td>
        <td width="60">&nbsp;</td>
    </tr>
</table>


<!-- index-33  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" width="100%" height="100%" style="background-image: url('<?php echo $filePath; ?>/images/index33.jpg'); background-image-resize: 6; background-repeat:no-repeat;">
    <tr>
        <td width="570" height="794" align="center">
            <table border="0" cellpadding="0" cellspacing="0" width="350" height="794" style="color: #fff;">
                <tr>
                    <td colspan="2" height="110">&nbsp;</td>
                </tr>
                <tr>
                    <td height="210" width="140" valign="center" align="left ">
                        <table height="210" width="150" align="left" border="0" cellpadding="0" cellspacing="0" style="font-family: 'avenir-lt-std-roman'; line-height: 1.4; font-size: 19px; text-align: center; padding-right: 15px;">
                            <tr>
                                <td valign="top">% Decrease in GHG Emission (Scope 1)
                                    <span style="font-size: 40px;">42%</span><br>
                                    as compared to 2019
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td height="210" width="150" align="left" valign="top">
                        <table height="210" align="left" valign="top" width="150" border="0" cellpadding="0" cellspacing="0" style="font-family: 'avenir-lt-std-roman'; line-height: 1.4; font-size: 19px; text-align: center;">
                            <tr>
                                <td valign="top">Decrease in <br> GHG Emission <br> (Scope 1)
                                    <span style="font-size: 40px;">10,453,053</span><br>
                                    tCO2e as <br> compared to 2019
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="left" valign="middle" height="145" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff;">GHG EMISSIONS</td>
                </tr>
                <tr>
                    <td colspan="2" valign="top" height="313" style="font-family: 'avenir-lt-std-roman'; line-height: 1.4; font-size: 16px; text-align: justify; color: #fff; padding-top: 15px;">
                        When direct and indirect emissions are
                        measured, the GHG reduction impact becomes
                        clearer in a sustainability context. Controlling
                        green house gas is important in maintaining
                        Earth’s optimal temperature. Thus we measure
                        these aspects as well as part of our
                        environmental & sustainability goals.
                    </td>
                </tr>
            </table>
        </td>
        <td width="154" height="794">&nbsp;</td>
        <td width="333" height="794" valign="top">
            <table valign="top" border="0" cellpadding="0" cellspacing="0" width="333" height="794" style="font-family: 'lato-heavy'; font-size: 20px; line-height: 1.3; padding-top: 45px; text-align: center; color: #fff;">
                <tr>
                    <td align="left" style=" font-family: 'lato-regular'; font-size: 16px; padding-bottom: 4px; border-bottom: 1px solid #fff;">GHG Emission Intensity for 2021</td>
                </tr>
                <tr>
                    <td style="color: #4677bb; padding-top: 10px;">Scope 1</td>
                </tr>
                <tr>
                    <td width="86" height="88">
                        <img src="<?php echo $filePath; ?>/images/index33-1.png" width="86" height="88" alt="" style="padding: 10px 0;"><br>
                    </td>
                </tr>
                <tr>
                    <td>0.0129 <br>tCO2e/AED</td>
                </tr>
                <tr>
                    <td style="padding-bottom: 10px; font-size: 16px; border-bottom: 1px solid #fff;">of revenue earned</td>
                </tr>
                <tr>
                    <td style="color: #fcc15e; padding-top: 10px;">Scope 2</td>
                </tr>
                <tr>
                    <td width="86" height="88">
                        <img src="<?php echo $filePath; ?>/images/index33-2.png" width="86" height="88" alt="" style="padding: 10px 0;"><br>
                    </td>
                </tr>
                <tr>
                    <td>0.00008 <br>tCO2e/AED</td>
                </tr>
                <tr>
                    <td style="padding-bottom: 10px; font-size: 16px; border-bottom: 1px solid #fff;">of revenue earned</td>
                </tr>
                <tr>
                    <td style="color: #abd28c; padding-top: 10px;">Scope 3</td>
                </tr>
                <tr>
                    <td width="86" height="88">
                        <img src="<?php echo $filePath; ?>/images/index33-3.png" width="86" height="88" alt="" style="padding: 10px 0;"><br>
                    </td>
                </tr>
                <tr>
                    <td>0.00064 <br>tCO2e/AED</td>
                </tr>
                <tr>
                    <td style="font-size: 16px;">of revenue earned</td>
                </tr>
            </table>
        </td>
        <td width="60">&nbsp;</td>
    </tr>
</table>


<!-- index-34  -->
<table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index34.jpg'); background-repeat: no-repeat;">
    <tr>
        <td colspan="9" height="95">&nbsp;</td>
    </tr>
    <tr>
        <td width="70">&nbsp;</td>
        <td height="240" width="440" align="center">
            <table width="100%" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="3" align="left" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c; padding-bottom: 5px;">Direct GHG Emissions (Scope 1)</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #4677bb;">2019</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #fcc15e;">2020</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #abd28c;">2021</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index34-1.png" width="113" height="85" alt="" style="padding: 20px 0;"><br>
                        24,491,574 <br>tCO2e
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index34-2.png" width="113" height="85" alt="" style="padding: 20px 0;"><br>
                        14,876,413 <br>tCO2e
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index34-3.png" width="113" height="85" alt="" style="padding: 20px 0;"><br>
                        14,038,521 <br>tCO2e
                    </td>
                </tr>
            </table>
        </td>
        <td width="70">&nbsp;</td>
        <td width="440" align="center">
            <table width="100%" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="3" align="left" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c; padding-bottom: 5px;">Indirect GHG Emissions (Scope 2)</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #4677bb;">2019</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #fcc15e;">2020</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #abd28c;">2021</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index34-4.png" width="87" height="81" alt="" style="padding: 20px 0;"><br>
                        106,973 <br>tCO2e
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index34-5.png" width="87" height="81" alt="" style="padding: 20px 0;"><br>
                        82,190 <br>tCO2e
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index34-6.png" width="87" height="81" alt="" style="padding: 20px 0;"><br>
                        91,004 <br>tCO2e
                    </td>
                </tr>
            </table>
        </td>
        <td width="70">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="9" height="65">&nbsp;</td>
    </tr>
    <tr>
        <td width="1123" height="394" valign="top" align="center" colspan="9">
            <table table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="3" align="left" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c; padding-bottom: 5px;">Other Indirect GHG Emissions (Scope 3)</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #4677bb;">2019</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #fcc15e;">2020</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #abd28c;">2021</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center; padding-right: 15px;">
                        <img src="<?php echo $filePath; ?>/images/index34-7.png" width="99" height="99" alt="" style="padding: 20px 0;"><br>
                        732,131 <br>tCO2e
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center; padding-right: 15px;">
                        <img src="<?php echo $filePath; ?>/images/index34-8.png" width="99" height="99" alt="" style="padding: 20px 0;"><br>
                        499,224 <br>tCO2e
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index34-9.png" width="99" height="99" alt="" style="padding: 20px 0;"><br>
                        696,485 <br>tCO2e
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-35  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index35.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80" width="1124">&nbsp;</td>
    </tr>
    <tr>
        <td height="171">
            <table valign="top" border="0" cellpadding="0" cellspacing="0" height="171">
                <tr>
                    <td width="460" height="171" valign="top">
                        <table width="455" height="161" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                            <tr>
                                <td height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left:60px;">2022 GOALS</td>
                            </tr>
                        </table>
                    </td>
                    <td width="750" align="center">
                        <table width="500" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                                <td style="font-family: 'avenir-black'; font-size: 16px; color: #abd28c;">In view of the Environment and sustainability goals, we promise the following :</td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo $filePath; ?>/images/index35-1.jpg" width="493" height="123" alt="">
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="143">&nbsp;</td>
    </tr>
    <tr>
        <td height="110">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="140">&nbsp;</td>
                    <td width="232" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 15px;">
                        Target to reduce electricity &
                        water consumption

                    </td>
                    <td width="240" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 15px;">
                        To encourage reuse of
                        bed linen, towel and drive
                        tree planting

                    </td>
                    <td width="220" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 15px;">
                        To participate in efficient
                        reuse wherever safely
                        applicable

                    </td>
                    <td width="255" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px;">
                        Control the use of hazardous
                        aerosols, cooling gas and
                        chemicals
                    </td>
                    <td width="157">&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="130">&nbsp;</td>
    </tr>
    <tr>
        <td valign="top">
            <table align="center" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="270" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 20px;">
                        Increase green cover of our
                        premises in food forest and
                        Miyawaki way - thus helping
                        in Carbon sequestration, and
                        working towards carbonneutrality.

                    </td>
                    <td width="250" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 30px;">
                        To upkeep ISO 14001
                        certification
                    </td>
                    <td width="180" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px;">
                        Conducting ISO
                        awareness trainings
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="135">&nbsp;</td>
    </tr>
</table>


<!-- index-36  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index36.jpg'); background-image-resize: 6;">
    <tr>
        <td width="500" height="794" style=" padding-left: 53px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td width="444" style="font-family: 'lato-heavy'; font-size: 45px; font-weight: 800; color: #fff;">
                        SOCIAL STEWARDSHIP
                    </td>
                </tr>
                <tr>
                    <td height="42">&nbsp;</td>
                </tr>
                <tr>
                    <td>
                        <table width="280" border="0" cellpadding="0" cellspacing="0" style="font-family: 'montserrat'; font-size: 16px; font-weight: 500; color: #fff; line-height: 35px;">
                            <tr>
                                <td style="border-bottom: 1px solid #fff;  ">Human Assets</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">Equal Opportunity</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">Diversity of Employees</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">Training & Development</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">Customer Service</td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1px solid #fff;">2022 Goals</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
        <td width="622">
        </td>
    </tr>
</table>


<!-- index-37  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index37.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="100%">
            <table width="465" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left:40px;">HUMAN ASSETS</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
    <tr>
        <td height="513" width="1123" valign="top">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="80">&nbsp;</td>
                    <td>
                        <table width="617" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                                <td valign="top" height="160" width="80">
                                    <img src="<?php echo $filePath; ?>/images/index37-1.jpg" width="55" height="43">
                                </td>
                                <td align="center" height="160" valign="middle" width="370" style="font-family: 'lato-heavy'; font-size: 23px; color: #21305c; padding-right: 130px;">
                                    We’re taking efforts across our
                                    value chain and industry to promote
                                    human rights for all."
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" valign="top" width="617" height="364" style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align:justify; line-height: 22px;">
                                    An organization is only as good as its people. Our people have elevated us to the top at all
                                    times. While we work hard to motivate our employees, improve their abilities, and give
                                    equitable chances for advancement, they repay us with their loyalty and trust. <br>
                                    We appreciate each employee and strive to create an atmosphere that is compassionate,
                                    inclusive, inspiring and rewarding for everyone. Through excellent training and personal
                                    development, we bring out the best in our employees, allowing them to have a rewarding
                                    career with XYZ (Company Name).

                                    <br><br>
                                    Within and outside our work culture, XYZ (Company Name) is committed to fostering
                                    diversity, gender equality, and employee well-being. We volunteer our time, talents, and
                                    resources to help our destinations build capacity and resilience, particularly during disasters.
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td width="369">&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-38  -->
<table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index38.jpg'); background-repeat: no-repeat;">
    <tr>
        <td colspan="9" height="95">&nbsp;</td>
    </tr>
    <tr>
        <td width="70">&nbsp;</td>
        <td height="240" width="440" align="center">
            <table width="100%" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="3" align="left" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c; padding-bottom: 5px;">Total Number of employees -</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #4677bb;">2019</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #fcc15e;">2020</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #abd28c;">2021</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index38-1.png" width="73" height="73" alt="" style="padding: 20px 0;"><br>
                        27481
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index38-2.png" width="73" height="73" alt="" style="padding: 20px 0;"><br>
                        23636
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index38-3.png" width="73" height="73" alt="" style="padding: 20px 0;"><br>
                        25524.5
                    </td>
                </tr>
            </table>
        </td>
        <td width="70">&nbsp;</td>
        <td width="440" align="center">
            <table width="100%" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="3" align="left" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c; padding-bottom: 5px;">Total enterprise headcount by part time employees -</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #4677bb;">2019</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #fcc15e;">2020</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #abd28c;">2021</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index38-4.png" width="72" height="72" alt="" style="padding: 20px 0;"><br>
                        10
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index38-5.png" width="72" height="72" alt="" style="padding: 20px 0;"><br>
                        10
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index38-6.png" width="72" height="72" alt="" style="padding: 20px 0;"><br>
                        10
                    </td>
                </tr>
            </table>
        </td>
        <td width="70">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="9" height="65">&nbsp;</td>
    </tr>
    <tr>
        <td width="1123" height="394" valign="top" align="center" colspan="9">
            <table table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="3" align="left" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c; padding-bottom: 5px;">Total enterprise headcount held by contractors/consultants -</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #4677bb;">2019</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #fcc15e;">2020</td>
                    <td style="font-family: 'Lato-heavy'; font-size: 20px; padding-top: 10px; color: #abd28c;">2021</td>
                </tr>
                <tr>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center; padding-right: 15px;">
                        <img src="<?php echo $filePath; ?>/images/index38-7.png" width="79" height="79" alt="" style="padding: 20px 0;"><br>
                        69
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center; padding-right: 15px;">
                        <img src="<?php echo $filePath; ?>/images/index38-8.png" width="79" height="79" alt="" style="padding: 20px 0;"><br>
                        62
                    </td>
                    <td style="font-family: 'Lato-heavy'; font-size: 17px; text-align: center;">
                        <img src="<?php echo $filePath; ?>/images/index38-9.png" width="79" height="79" alt="" style="padding: 20px 0;"><br>
                        148
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-39  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index39.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="100%">
            <table width="465" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left:40px;">CASE STUDIES</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="50">&nbsp;</td>
    </tr>
    <tr>
        <td height="504" width="1123" valign="top" style="padding-left: 80px;">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="2" width="515" style="font-family: 'avenir-black'; font-size: 16px; text-align: center; line-height: 22px; color: #abd28c;">
                        Practicing within organizations is not always sufficient to make a
                        huge impact. Stepping out of the comfort zone and going outdoors
                        and setting an example is what makes our case studies special.
                    </td>
                </tr>
                <tr>
                    <td colspan="2" height="50">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">SOFITEL HOTELS & RESORTS DUBAI JUMEIRAH BEACH</td>
                    <td width="45">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">
                        <ul>
                            <li>CS Vydyanathan collected 53 kgs in the can collection drive
                                hosted by Emirates Environmental Group (EEG)</li>
                            <br>
                            <li>Clean Up UAE – Desert cleaning drive</li>
                        </ul>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-40  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index40.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="100%">
            <table width="465" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left:40px;">EQUAL OPPORTUNITY</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="40">&nbsp;</td>
    </tr>
    <tr>
        <td height="514" width="1123" valign="top">
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td width="80">&nbsp;</td>
                    <td width="100%">
                        <table width="485" border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td align="left" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c; padding-bottom: 5px;">GHG Emission Intensity for 2021</td>
                                <td width="200">&nbsp;</td>
                            </tr>
                            <tr>
                                <td colspan="2" style="padding: 40px 0;">
                                    <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                        <tr>
                                            <td valign="top" width="216" height="164" style="padding-right: 20px;">
                                                <img src="<?php echo $filePath; ?>/images/index40-1.png" width="216" height="164">
                                            </td>
                                            <td valign="top" width="216" height="164" style="padding-right: 20px;">
                                                <img src="<?php echo $filePath; ?>/images/index40-2.png" width="216" height="164">
                                            </td>
                                            <td valign="top" width="216" height="164">
                                                <img src="<?php echo $filePath; ?>/images/index40-3.png" width="216" height="164">
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" valign="top" width="600" style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align:justify; line-height: 22px; padding-right: 90px;">
                                    Men and women need to have equal opportunities and advantages. We at XYZ
                                    (Company Name) do not discriminate against our employees. We guarantee an
                                    environment of equal opportunities and rights to both men and women. We employ
                                    men and women at all levels and do not discriminate roles based on gender. Our
                                    employees are our assets. We at XYZ (Company Name) give utmost importance to
                                    equal opportunity and rights for all because we believe it is essential for the growth of
                                    the individuals and the organization. <br>
                                    We have constantly been improvising on our male to female compensation ratio
                                    bringing it to 1.03:1 in 2021 from 1.24:1 in 2019.
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td width="350">&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-41  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index41.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="100%">
            <table width="465" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left:40px;">DIVERSITY OF EMPLOYEES</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="40">&nbsp;</td>
    </tr>
    <tr>
        <td height="514" width="1123" valign="top">
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td width="80">&nbsp;</td>
                    <td width="100%">
                        <table width="485" border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td align="left" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; border-bottom: 1px solid #21305c; padding-bottom: 5px;">Our CSR Investments in last 3 years</td>
                                <td width="200">&nbsp;</td>
                            </tr>
                            <tr>
                                <td colspan="2" style="padding: 40px 0;">
                                    <table valign="top" border="0" cellpadding="0" cellspacing="0" width="100%">
                                        <tr>
                                            <td valign="top" width="218" height="143" style="padding-right: 20px;">
                                                <img src="<?php echo $filePath; ?>/images/index41-1.jpg" width="218" height="143">
                                            </td>
                                            <td valign="top" width="218" height="143" style="padding-right: 20px;">
                                                <img src="<?php echo $filePath; ?>/images/index41-2.jpg" width="218" height="143">
                                            </td>
                                            <td valign="top" width="170" height="143">
                                                <img src="<?php echo $filePath; ?>/images/index41-3.jpg" width="170" height="143">
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" valign="top" width="600" style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align:justify; line-height: 22px; padding-right: 90px;">
                                    Equality in diversity is our motto. Every employee is an independent individual. We respect
                                    and value their individuality. We aim to foster a sense of belonging that celebrates,
                                    promotes and most importantly respects all individuals. We believe in a culture of
                                    inclusiveness for guests and team members of all backgrounds, genders, sexual identities,
                                    abilities, heritage, and beliefs that contribute to our success. We foster a workplace wherein everyone is respected and treated with kindness. We encourage everyone to achieve
                                    their personal and professional goals and objectives. We also plan to incentivize the
                                    payments of our employees in the coming years on sustainability parameters.

                                </td>
                            </tr>
                        </table>
                    </td>
                    <td width="350">&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-42  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index42.jpg'); background-repeat: no-repeat;">
    <tr>
        <td colspan="2" height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="465">
            <table width="480" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left:40px;">TRAINING AND DEVELOPMENT</td>
                </tr>
            </table>
        </td>
        <td valign="bottom" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; padding-left: 20px;">
            Our dedicated training department
            manages comprehensive training and
            development programmes. Some of
            them are on-the-job training</td>
        <td width="350">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2" height="130" style="padding: 15px 0;">
            <table width="100%" height="130" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="60">&nbsp;</td>
                    <td width="164" height="115">
                        <img src="<?php echo $filePath; ?>/images/index42-1.jpg" width="164" height="115">
                    </td>
                    <td width="300" style="font-family: 'avenir-lt-std-roman'; font-size: 16px; line-height: 1.4; padding: 0 40px;">
                        Total hours of training
                        provided to our employees in
                        last 3 years -
                    </td>
                    <td align="center" style="font-family: 'avenir-lt-std-book'; font-size: 42px; color: #203d71;">110,000+ Hours</td>
                </tr>
            </table>
        </td>
        <td width="350">&nbsp;</td>
    </tr>
    <tr>
        <td height="185" colspan="2" style="padding-left: 60px;">
            <table border="0" cellpadding="0" cellspacing="0" width="90%">
                <tr>
                    <td colspan="3" style="padding: 15px; border-top: 1px solid #000; border-bottom: 1px solid #000;">
                        <img src="<?php echo $filePath; ?>/images/index42-2.jpg" width="592" height="155">
                    </td>
                </tr>
                <tr>
                    <td height="221" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 16px; text-align:justify; line-height: 22px; padding-top: 20px;">We align our training and development programs with our company goals which are long
                        term, which results in improved leadership skills and general well-being. We provide
                        training and development for our employees at all levels. We give on the job technical
                        training to enhance the talents of our workers.
                        <br><br>
                        Talent management is both essential and critical in the corporate world today. Fostering
                        talent in a competitive environment creates future leaders.</td>
                </tr>
            </table>
        </td>
        <td width="350">&nbsp;</td>
    </tr>
</table>


<!-- index-43  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index43.jpg'); background-image-resize: 6;">
    <tr>
        <td width="1122" height="794" align="center">
            <table width="475" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">LIFE-SAVING TRAINING- PARK HYATT ABU DHABI HOTELS & VILLAS</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">For the safety and wellbeing of our employees, we conducted
                        basic training on first aid and life-saving.</td>
                </tr>
                <tr>
                    <td height="55">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">FIRE SAFETY TRAINING</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">Another initiative for the safety and well-being of the
                        employees was conducted at Park Hyatt Abu Dhabi Hotels &
                        Villas. We conducted was fire safety training. We strongly care
                        and believe in keeping our employees healthy and safe and
                        conduct such training from time to time.</td>
                </tr>
                <tr>
                    <td height="55">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">Injury rate across XYZ (Company Name) Group -</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td height="117" style="padding-top: 20px;">
                        <img src="<?php echo $filePath; ?>/images/index43-1.jpg" width="59" height="117" style="padding-right: 30px;">
                        <img src="<?php echo $filePath; ?>/images/index43-2.jpg" width="59" height="117" style="padding-right: 30px;">
                        <img src="<?php echo $filePath; ?>/images/index43-3.jpg" width="59" height="117">
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-44  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index44.jpg'); background-image-resize: 6;">
    <tr>
        <td width="1122" height="794" align="center">
            <table width="475" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">EVACUATION DRILL - LE MERIDIEN ABU DHABI</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">We care about the safety and security of our    people, for their well-being, we conducted an evacuation drill that prepared them
                        to be alert and aware while dealing with a fire accident situation.
                    </td>
                </tr>
                <tr>
                    <td height="55">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">FIRST AID TRAINING - LE MERIDIAN ABU DHABI</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">For the safety and wellbeing of our employees, we conducted basic training on first aid.

                    </td>
                </tr>
                <tr>
                    <td height="55">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">LE MERIDIEN ABU DHABI</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td height="117" valign="top" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">
                        We conducted chemical safety training for our employees.
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-45  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index45.jpg'); background-image-resize: 6;">
    <tr>
        <td width="1122" height="794" align="center">
            <table width="475" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">BLOOD DONATION CAMPAIGN</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">As part of our corporate social responsibility, focusing on health
                        and safety, our subsidiary - Al Ghazal Transportation Company,
                        conducted a blood donation campaign coordinating with ITC.
                    </td>
                </tr>
                <tr>
                    <td height="55">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">PARK HYATT ABU DHABI HOTELS & VILLAS -</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">
                        <ul>
                            <li>Compliance to WHO recommendations</li><br>
                            <li>Go Safe certification by Abu Dhabi Department of Culture & tourism</li><br>
                            <li>Currently pursuing GBAC STAR (Global Biorisk Advisory Council) certification</li><br>
                            <li>Appointment of a specialist professional - Hygiene &
                                wellbeing manager to ensure safety and cleaning standards</li><br>
                            <li>Blood donation drive</li><br>
                            <li>Use of solar energy for water heating</li><br>
                        </ul>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-46  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index46.jpg'); background-image-resize: 6;">
    <tr>
        <td width="1122" height="794" align="center">
            <table width="475" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">BLOOD DONATION CAMPAIGN- RADISSON BLU AL AIN</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">As part of health and safety initiatives and corporate social responsibilities, we conducted a blood donation camp for all our
                        employees on February 15th, 2022</td>
                </tr>
                <tr>
                    <td height="55">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">LE MERIDIEN ABU DHABI –</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">Our employee's health and safety matter to us. As part of our corporate social responsibilities, we conducted a free eye test
                        for all of them on November 3rd, 2021.</td>
                </tr>
                <tr>
                    <td height="55">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">BREAST CANCER AWARENESS-</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">For the welfare and safety of our women employees, we conducted a breast cancer awareness campaign
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-47  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index47.jpg'); background-image-resize: 6;">
    <tr>
        <td width="1122" height="794" align="center">
            <table width="475" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">EMPLOYEE WELL BEING -</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">We face a range of material issues related to human resources in
                        our hotels and subsidiaries, including talent acquisition and
                        retention, training and development, succession planning,
                        employee engagement and occupational health and safety. We
                        strive to manage all these issues keeping our employee wellbeing as a center of focus.

                    </td>
                </tr>
                <tr>
                    <td height="55">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">PARK HYATT ABU DHABI HOTELS & VILLAS - PHOTO SHOOT</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">We conducted a special photo session to celebrate the journey
                        of our employees and make them part of the legacy of our
                        company.

                    </td>
                </tr>
                <tr>
                    <td height="55">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">HOUSEKEEPING WEEK - PARK HYATT ABU DHABI HOTELS & VILLAS</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td height="117" valign="top" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">
                        Between 12- 18 of September, we celebrated International
                        Housekeeping Week. We conducted many activities such as
                        yoga, exercising, fun activities for our employees. <br>
                        We believe in enhancing our employees' personal life, along
                        with their professional ones.
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-48  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index48.jpg'); background-image-resize: 6;">
    <tr>
        <td width="1122" height="794" align="center">
            <table width="475" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">RADISSON BLU AL AIN -</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">In February 2022, We celebrated Valentine’s Day in our office as
                        we believe that personal development is essential in addition to
                        professional development.

                    </td>
                </tr>
                <tr>
                    <td height="55">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; font-weight: 900; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">ART EXHIBITION HOSTED BY PARK HYATT ABU
                        DHABI HOTELS & VILLAS</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">On 31 October 2021, we launched an art exhibition by a
                        British- Moroccan artist, DAZ “Art Changes Every Think”. It
                        featured a collection of DAZ’z new art pieces that showcase a
                        richness in colour, with messages and characters, impacting
                        and quirky in a Street Pop Art style.

                    </td>
                </tr>
                <tr>
                    <td height="55">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" align="left" style="font-family: 'lato-heavy';  font-size: 19px; padding-right: 50px; padding-bottom: 15px; line-height: 25px; color: #fcc15e;">BABY SITTING TRAINING - PARK
                        HYATT ABU DHABI HOTELS & VILLAS</td>
                </tr>
                <tr>
                    <td colspan="2" style="border-top: 1px solid #000; padding-bottom: 10px;"></td>
                </tr>
                <tr>
                    <td height="117" valign="top" style="font-family: 'avenir-lt-std-book'; text-align: justify; font-size: 16px; line-height: 20px;">
                        We conducted a baby sitting training for our new mother
                        employees.
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-49  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index49.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="100%">
            <table width="465" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" align="center" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff;">
                        CUSTOMER SERVICE</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="60">&nbsp;</td>
    </tr>
    <tr>
        <td height="493" width="1122" valign="top">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="80">&nbsp;</td>
                    <td width="565" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 1.38;">
                        The Group has well-established policies in place to protect the
                        safety of our guests, including hygiene and disinfection, food and
                        fire life safety, conflict resolution, crime prevention, medical
                        emergencies, and privacy and data protection. All hotels are
                        subject to annual audits to verify their compliance with the
                        Group’s standards and procedures.</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-50  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index50.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80" width="1124">&nbsp;</td>
    </tr>
    <tr>
        <td height="171">
            <table valign="top" border="0" cellpadding="0" cellspacing="0" height="171">
                <tr>
                    <td width="460" height="171" valign="top">
                        <table width="455" height="161" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                            <tr>
                                <td height="140" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left:60px;">2022 PLANS</td>
                            </tr>
                        </table>
                    </td>
                    <td width="750" align="center">

                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="150">&nbsp;</td>
    </tr>
    <tr>
        <td valign="bottom" height="110">
            <table valign="bottom" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="140">&nbsp;</td>
                    <td width="232" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 15px;">
                        Employee wellbeing

                    </td>
                    <td width="240" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 15px;">
                        Corporate social <br>
                        responsibilities

                    </td>
                    <td width="220" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 15px;">
                        Unity in diversity

                    </td>
                    <td width="255" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px;">
                        Health and safety
                    </td>
                    <td width="157">&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="130">&nbsp;</td>
    </tr>
    <tr>
        <td valign="top">
            <table align="center" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="270" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 20px;">
                        Customer Safety
                        & Satisfaction

                    </td>
                    <td width="250" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px; padding-right: 30px;">
                        Women employment
                        & Emiratisation
                    </td>
                    <td width="180" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px;">
                        Comfortable working
                        environment
                    </td>
                    <td width="180" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 15px; text-align: center; line-height: 22px;">
                        Equal opportunity
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="135">&nbsp;</td>
    </tr>
</table>


<!-- index-51  -->
<table border="0" width="1123" height="794" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index51.jpg'); background-image-resize: 6;">
    <tr>
        <td width="50" height="794" style="padding-left: 60px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td width="275" style="font-family: 'lato-heavy'; font-size: 45px; font-weight: 800; color: #fff; padding-top: 70px; padding-bottom: 40px;">
                    ETHICAL <br> GOVERNANCE
                    </td>
                </tr>
            </table>
        </td>
        <td width="623" height="795">
        </td>
    </tr>
</table>


<!-- index-52  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index52.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="80">&nbsp;</td>
    </tr>
    <tr>
        <td width="100%">
            <table width="465" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" align="left" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left: 50px;"> ETHICAL <br> GOVERNANCE</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="60">&nbsp;</td>
    </tr>
    <tr>
        <td height="493" width="1122" valign="top">
            <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="80">&nbsp;</td>
                    <td width="565" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 1.38;">
                        We have constantly improved the inherent corporate governance framework to
                        maintain a healthy corporate governance environment and implement best
                        practices. <br> <br>
                        Despite the challenges posed by the worldwide pandemic, relevant corporate
                        governance procedures were implemented by strengthening and applying
                        corporate governance concepts across all of the group’s activities in 2021. <br><br>
                        XYZ (Company Name) follows a strict Ethics and Prevention of Corruption policy.
                        100% of our employees comply with the policy. We also follow human rights
                        policy, which also covers our suppliers. <br> <br>
                        The Board of Directors and Executive Management believe that the primary goal
                        of corporate governance is to protect the interests of stakeholders sustainably
                        while also contributing to improved corporate performance and accountability in
                        creating long-term shareholder value.
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-53  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index53.jpg'); background-repeat: no-repeat; padding: 60px 80px;">
    <tr>
        <td width="828" height="792" valign="top" style="padding-right: 20px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" valign="top">
                <tr>
                    <td height="220" style="font-family: 'lato-heavy';  font-size: 40px; color: #fff;">CORPORATE STRUCTURE</td>
                </tr>
                <tr>
                    <td width="100%">
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="font-family: 'avenir-lt-std-roman'; font-size: 15px; line-height: 26px; color: #fff;">
                            <tr>
                                <td width="200" align="center">
                                    <table border="0" cellpadding="0" cellspacing="0" align="center">
                                        <tr>
                                            <td height="120">Board of Directors</td>
                                        </tr>
                                        <tr>
                                            <td align="center" height="260">Head- Corporate <br> Governance & Board <br>Secretary</td>
                                        </tr>
                                    </table>
                                </td>
                                <td width="305" valign="top">
                                    <table border="0" cellpadding="0" cellspacing="0" align="center" valign="top" style="font-family: 'avenir-lt-std-roman'; font-size: 15px; line-height: 26px; color: #fff; text-align: center;">
                                        <tr>
                                            <td>Supervision & follow up Commitee</td>
                                        </tr>
                                        <tr>
                                            <td height="50">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>Audit compliance & CG Commitee</td>
                                        </tr>
                                        <tr>
                                            <td height="50">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>Board Exec. Commitee</td>
                                        </tr>
                                        <tr>
                                            <td height="50">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>NCHR Commitee</td>
                                        </tr>
                                    </table>
                                </td>
                                <td width="255" valign="top">
                                    <table border="0" cellpadding="0" cellspacing="0" align="center" valign="top" style="font-family: 'avenir-lt-std-roman'; font-size: 15px; line-height: 26px; color: #fff; text-align: center;">
                                        <tr>
                                            <td height="60">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>Head of Int. Audit & Compl, Governance Officer</td>
                                        </tr>
                                        <tr>
                                            <td height="60">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>CEO</td>
                                        </tr>
                                        <tr>
                                            <td height="70">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>Personal Asst</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
        <td width="300" height="792" align="center" valign="top" style=" padding-left: 10px;">
            <table width="210" align="top" border="0" cellpadding="0" cellspacing="0" style="font-family: 'avenir-lt-std-roman'; font-size: 15px; line-height: 26px; color: #fff;  padding-top: 20px;">
                <tr>
                    <td align="left">Legal Manager - <br>Head of Legal</td>
                </tr>
                <tr>
                    <td height="40">&nbsp;</td>
                </tr>
                <tr>
                    <td align="right">Travel Manager</td>
                </tr>
                <tr>
                    <td height="60">&nbsp;</td>
                </tr>
                <tr>
                    <td align="left">Head of HR</td>
                </tr>
                <tr>
                    <td height="40">&nbsp;</td>
                </tr>
                <tr>
                    <td align="right">Sr Mgr- Prop. Dev <br> & Engg</td>
                </tr>
                <tr>
                    <td height="40">&nbsp;</td>
                </tr>
                <tr>
                    <td width="100%">
                        <table width="100%" align="left" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                                <td align="left" width="100px">CFO</td>
                                <td align="right" width="100px">IT Manager</td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="50">&nbsp;</td>
                </tr>
                <tr>
                    <td align="right">Corporate Director <br> of Maintenance</td>
                </tr>
                <tr>
                    <td height="20">&nbsp;</td>
                </tr>
                <tr>
                    <td align="left">Sr Manager <br> Procurement</td>
                </tr>
                <tr>
                    <td height="20">&nbsp;</td>
                </tr>
                <tr>
                    <td align="right">VP Hotel <br> Operns</td>
                </tr>
                <tr>
                    <td height="20">&nbsp;</td>
                </tr>
                <tr>
                    <td align="left">VP Asset <br> Mgmt</td>
                </tr>
                <tr>
                    <td height="20">&nbsp;</td>
                </tr>
                <tr>
                    <td align="right">Head. Gov Ref & <br> Admin</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-60  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index60.jpg'); background-repeat: no-repeat; padding: 60px 80px;">
    <tr>
        <td width="753" height="792" valign="top" style="font-family: 'lato-heavy';  font-size: 40px; color: #4677bb; padding-right: 20px;">PRIORITIZED MATERIALITY TOPICS -</td>
        <td width="369" height="792" align="left" valign="top">
            <table border="0" cellpadding="0" cellspacing="0" align="left" style="font-family: 'lato-heavy';  font-size: 16px; line-height: 26px;">
                <tr>
                    <td height="215">&nbsp;</td>
                </tr>
                <tr>
                    <td style=" color: #4677bb;">
                        <ul>
                            <li>Safety and Security</li>
                            <li>Energy and Carbon</li>
                            <li>Water Management</li>
                            <li>Waste Management</li>
                            <li>Data Privacy</li>
                            <li>Customer Satisfaction</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <td height="35">&nbsp;</td>
                </tr>
                <tr>
                    <td style="color: #fcc15e;">
                        <ul>
                            <li>Employee Welfare</li>
                            <li>Responsible Procurement</li>
                            <li>Working Culture</li>
                            <li>Training and Development</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <td height="35">&nbsp;</td>
                </tr>
                <tr>
                    <td style="color: #90b11c;">
                        <ul>
                            <li>Corporate Volunteering</li>
                            <li>Talent Attraction and Development</li>
                            <li>Human Rights and Inclusiveness</li>
                            <li>Equal Opportunity</li>
                        </ul>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-61  -->
<table border="0" cellpadding="0" cellspacing="0" align="center" >
    <tr>
        <td width="100%" height="140">
            <table width="635" height="140" border="0" cellpadding="0" cellspacing="0" style=" background-color: #203d71; padding: 10px 0;">
                <tr>
                    <td height="140" align="left" style="font-family: 'lato-heavy'; font-size: 40px; font-weight: 800; color: #fff; border-top: 1px solid #fff; border-bottom: 1px solid #fff; padding-left: 60px;">ADX ESG INDEX</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="25">&nbsp;</td>
    </tr>
    <tr>
        <td width="1123" valign="top" style="padding: 0 50px;">
            <table cellpadding="0" cellspacing="0" width="100%" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 16px; line-height: 1.4; border: 1px solid #fff; padding-left: 20px;">
                <tr>
                    <td colspan="4" height="50" bgcolor="#fcc15e" style="font-family: 'lato-heavy'; color:#fff; border: 1px solid #fff; padding-left: 20px;">ENVIRONMENTAL DISCLOSURES :</td>                    
                </tr>
                <tr>
                    <td colspan="4" height="50" bgcolor="#4677bb" style="font-family: 'lato-heavy'; color:#fff; border: 1px solid #fff; padding-left: 20px;">E-1 GHG EMISSIONS:</td>                    
                </tr>
                <tr style="background: #abd28c;">
                    <td width="340" style="padding: 15px 20px; border: 1px solid #fff;">E1.1) Total amount in CO2 equivalents, for Scope 1</td>
                    <td width="220" style="padding: 15px 20px; border: 1px solid #fff;">GRI 305: Emissions 2016</td>
                    <td width="215" style="padding: 15px 20px; border: 1px solid #fff;">SDG 13: Climate Action</td>
                    <td style="padding: 15px 20px; border: 1px solid #fff;">Page 35</td>
                </tr>
                <tr style="background: #def1cf;">
                    <td style="padding: 15px 20px; border: 1px solid #fff;">E1.2) Total amount, in CO2 equivalents, for Scope 2 (if applicable)</td>
                    <td style="padding: 15px 20px; border: 1px solid #fff;">GRI 305: Emissions 2016</td>
                    <td style="padding: 15px 20px; border: 1px solid #fff;">SDG 13: Climate Action</td>
                    <td style="padding: 15px 20px; border: 1px solid #fff;">Page 35</td>
                </tr>
                <tr style="background: #abd28c;">
                    <td style="padding: 15px 20px; border: 1px solid #fff;">E1.3) Total amount, in CO2 <br> equivalents, for Scope 3 <br>(if applicable)</td>
                    <td style="padding: 15px 20px; border: 1px solid #fff;">GRI 305: Emissions 2016</td>
                    <td style="padding: 15px 20px; border: 1px solid #fff;">SDG 13: Climate Action</td>
                    <td style="padding: 15px 20px; border: 1px solid #fff;">Page 35</td>
                </tr>
                <tr>
                    <td colspan="4" height="50" bgcolor="#4677bb" style="font-family: 'lato-heavy'; color:#fff; border: 1px solid #fff; padding-left: 20px;">E2 - EMISSIONS INTENSITY</td>                    
                </tr>
                <tr style="background: #abd28c;">
                    <td style="padding: 15px 20px; border: 1px solid #fff;">E2.1) Total GHG emissions per output scaling factor</td>
                    <td style="padding: 15px 20px; border: 1px solid #fff;">GRI 305: Emissions 2016</td>
                    <td style="padding: 15px 20px; border: 1px solid #fff;">SDG 13: Climate Action</td>
                    <td style="padding: 15px 20px; border: 1px solid #fff;">Page 34</td>
                </tr>
                <tr style="background: #def1cf;">
                    <td style="padding: 15px 20px; border: 1px solid #fff;">E2.2) Total non-GHG emissions per output scaling factor </td>
                    <td style="padding: 15px 20px; border: 1px solid #fff;">GRI 305: Emissions 2016</td>
                    <td style="padding: 15px 20px; border: 1px solid #fff;">SDG 13: Climate Action</td>
                    <td>&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-70  -->
<table border="0" cellpadding="0" cellspacing="0" height="794" width="1123" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index70.jpg'); background-repeat: no-repeat;">
    <tr>
        <td width="1123" valign="top" style="padding: 0 50px;">
            <table cellpadding="0" cellspacing="0" width="100%" valign="top" style="font-family: 'avenir-lt-std-book'; font-size: 16px; line-height: 1.4; padding-left: 20px; padding-top: 50px;">
                <tr>
                    <td colspan="4" height="50" bgcolor="#4677bb" style="font-family: 'lato-heavy'; color:#fff; border: 1px solid #fff; padding-left: 20px;">G9 - EXTERNAL ASSURANCE</td>                    
                </tr>
                <tr style="background: #abd28c;">
                    <td valign="top" width="340" style="padding: 15px 20px; border: 1px solid #fff;">Are your sustainability disclosures assured or verified by a third party audit firm? Yes/No</td>
                    <td valign="top"  width="220" style="padding: 15px 20px; border: 1px solid #fff;">GRI 103: Management Approach 2016 is to be used in combination with the topic specific standards</td>
                    <td valign="top" width="215" style="padding: 15px 20px; border: 1px solid #fff;"></td>
                    <td valign="top" style="padding: 15px 20px; border: 1px solid #fff;">No, we choose to have an internal assurance since this is our second year of reporting.</td>
                </tr>
                <tr>
                    <td colspan="4" height="475">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="4" valign="top" style="font-size: 14px;">Disclaimer: Some data reported this year might differ from last year's baseline sustainability reporting, mainly because we keep enhancing our procedures with increased data reporting from our group entities, towards more detail-oriented and exhaustive ESG disclosures. Our commitment is to always strive for the best reporting every year.</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-71  -->
<table border="0" cellpadding="0" cellspacing="0" height="794" width="1123" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index71.jpg'); background-repeat: no-repeat;">
    <tr>
        <td width="1123" height="795" valign="top">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" valign="top">
                <tr>
                    <td height="55">&nbsp;</td>
                </tr>
                <tr>
                    <td height="105" width="1123" bgcolor="#fff" align="center" valign="middle">
                        <img src="<?php echo $filePath; ?>/images/Asset-6.jpg" alt="ist" valign="middle" width="598" height="40" />
                    </td>
                </tr>
                <tr>
                    <td align="center" valign="middle" style="font-family: 'lato-regular';  font-size: 16px; line-height: 26px; color: #464648; padding: 20px 0;"><span style="font-family: 'lato-heavy';">ABU DHABI NATIONAL HOTELS</span> <br>
                        <span style="font-family: 'lato-heavy';">P.O. BOX </span> 46806, ABU DHABI, UAE<br>
                        <span style="font-family: 'lato-heavy';">TEL:</span> +971 2 444 7228<br>
                        <span style="font-family: 'lato-heavy';">MAIL:</span> INFO@XYZ (Company Name).COM
                    </td>
                </tr>
                <tr>
                    <td height="490">
                        <table border="0" cellpadding="0" cellspacing="0" align="center">
                            <tr>
                                <td>
                                    <img src="<?php echo $filePath; ?>/images/index71-1.png" width="51" height="30" />
                                </td>
                            </tr>
                            <tr>
                                <td width="380" style="font-family: 'lato-heavy';  font-size: 18px; line-height: 26px; text-align:center; padding: 0 20px;">Hospitality is beyond serving. It's about
                                    inculcating a lifestyle! <br>
                                    While we are fortunate to touch millions
                                    of hearts every year, we pledge to bring
                                    an unshakable commitment, towards a
                                    sustainable tomorrow.</td>
                            </tr>
                            <tr>
                                <td align="right">
                                    <img src="<?php echo $filePath; ?>/images/index71-2.png" width="51" height="30" />
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-16 left-side-simillar pages -->
<table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index16.jpg'); background-repeat: no-repeat;">
    <tr>
        <td valign="top" width="593" height="299" style="padding-left: 65px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" height="298" style="color: #ff1616;">
                <tr>
                    <td height="50">&nbsp;</td>
                </tr>
                <tr>
                    <td width="470" style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c; margin-right: 30px;">Address Hotel Dubai Mall</td>
                    <!-- <td width="50">&nbsp;</td> -->
                </tr>
                <tr>
                    <td width="470" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px;">
                        Address Dubai Mall, with a staff headcount of 100 in 2021, has
                        hosted thousands of guests in 2021. With a 15-min walk from Burj
                        Khalifa, it offers a wide range of luxury suites to choose from. With
                        regard to work-related injuries and safety incidents, the hotel has
                        accounted for less than 5 injuries in 2021. Non-discrimination and
                        human rights parameters are embedded in the Company
                        Standards of Conduct Policy. With a healthy occupancy rate and a
                        fair gender equality ratio in the workforce this organization has
                        been an important part of the XYZ (Company Name) group.
                    </td>
                    <!-- <td width="50">&nbsp;</td> -->
                </tr>
            </table>
        </td>
        <td width="530"></td>
    </tr>
    <tr>
        <td colspan="2" height="180">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2" height="315" valign="top">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" height="315" valign="top" style="color: #ff1616;">
                <tr>
                    <td width="520"></td>
                    <td width="625" height="285" valign="top" style="padding-right: 55px; padding-top: 20px;">
                        <table valign="top" border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c;">Sheraton Abu Dhabi Hotel and Resort</td>
                            </tr>
                            <tr>
                                <td valign="top" style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px;">
                                    A well-known beach resort in XYZ (Company Name) group, Sheraton
                                    Abu Dhabi is a center for entertainment, fitness, business and leisure
                                    visitors. The staff teams are well versed in Covid-19 measures and
                                    hygiene and cleanliness standards. Screening and sanitization of sites
                                    and operational excellence go hand in hand in this partner organization.
                                    Having sustainable supply chains in place makes for a perfect example of
                                    sustainable business models.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<!-- index-12 right-side-simillar pages -->
<table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%" align="center" style="background-image: url('<?php echo $filePath; ?>/images/index12.jpg'); background-repeat: no-repeat;">
    <tr>
        <td height="55">&nbsp;</td>
    </tr>
    <tr>
        <td valign="top" height="270">
            <table height="270" border="0" cellpadding="0" cellspacing="0" width="100%" style="color: #ff1616;">
                <tr>
                    <td width="605"></td>
                    <td width="270" height="245" valign="top" style=" padding-right: 50px;">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" height="270">
                            <tr>
                                <td style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c;">Sunshine Travels & Tours</td>
                            </tr>
                            <tr>
                                <td style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px;">
                                    Sunshine is a renowned travel and tours services provider in XYZ
                                    (Company Name). Ranging from flight & hotel bookings, limo
                                    services, tour packages, airport meet & assist, transfers & transport
                                    up to visa processing, a wide gamut of services is on the offer. With
                                    more than 2700 registered rooms and executive suites and
                                    impeccable adherence to environmental needs, Sunshine leads the
                                    group with a responsible track record of being a green business.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td height="200">&nbsp;</td>
    </tr>
    <tr>
        <td height="338" valign="top" style="padding-left: 95px; ">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" valign="top" style="color: #ff1616;">
                <tr>
                    <td width="565" height="313" valign="top">
                        <table height="313" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                                <td style="font-family: 'lato-heavy'; font-size: 19px; line-height: 1.4; font-weight: 800; border-bottom: 1px solid #21305c; padding-top: 15px;">Al Ghazal Transportation Company</td>
                            </tr>
                            <tr>
                                <td style="font-family: 'avenir-lt-std-roman'; text-align: justify; font-size: 16px; line-height: 22px; padding-top: 15px;">
                                    Al Ghazal started the business over 30 years ago. The range of
                                    services includes Bus transportation, vehicle rentals, leasing, VIP
                                    limos, maintenance and car repair services throughout the country. As
                                    an organization, they are committed to eco-friendly initiatives, in
                                    addition, to providing their guests with a world-class transportation
                                    service.
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td width="560">&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


