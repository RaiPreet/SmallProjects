<div id="tribe_page_loader"></div>
<div class="row px-0">

  <!-- LEFT COLUMN -->
  <div id="groupinfo" class="col-md-3 px-0">
    <aside class="sidebar" id="sidebar" data-plugin-sticky data-plugin-options="{'minWidth': 991, 'containerSelector': '.row', 'padding': {'top': 74}}">
      <img class="img mb-0 pb-0" style="width: 100%" id="tribe_user_profile_pic" src="<?php echo '/files/sites/4/data/slider2.jpg'; ?>" alt="VIP Membership">
      <section class="section section-primary p-2 pl-3 m-0">
        <h4 class="px-3">Group by The Bulletproof Husband&trade;</h4>
      </section>
      <div class="col-md-12 p-4">
        <h2 class="heading heading-secondary bold mb-none">TBH VIP Membership</h2>
        <h4><i class="fa fa-lock"></i> Private group - <span id="tribe_member_count"></span> members</h4>
        <div id="tribe_member_list">
          
        </div>
        <div id="tribe_members_load_more" data-page="0" data-perPage="5" class="btn btn-primary bold">
          Load More 
        </div>
        <hr class="small">
        <h4 class="bold">Your marriage<br/>
            Your terms<br/>
            Your life</h4>
      </div> 
    </aside>
  </div>
  
  <!-- PAGE HEADER -->
  <div class="col-md-9 p-0 m-0" style="background: #F0F2F5; min-height: 100vh">
    <section class="page-header page-header-classic page-header-sm mb-3 px-0">
      <div class="container">
        <div class="row">
          <div class="col-md-12 px-5">
            <h1 class="" data-title-border><?php echo $PAGE->title; ?></h1>
          </div>
        </div>
      </div>
    </section>
    <div class="row">

      <!-- MAIN COLUMN -->
      <div class="col-md-7">

        <!-- Write Something -->
        <div class="card ms-3 pt-3 card-border card-border-top rounded">
          <div class="card-content text-center">
            <div class="post-sec">
              <textarea id="tribe-post-content" class="form-control" placeholder="What's in your mind?" style="width: 90%; background: #F0F2F5;margin:0 auto;"></textarea>
              <ul class='list-inline post-actions'>
                  <li id="add_tribe_post" class='pull-right'><a href="#" class='btn btn-primary btn-xs'>Post</a></li>
              </ul>
            </div>
            <div class="mx-4 mt-3">
              <hr class="short" style="background: rgba(0,0,0,.25);">
            </div>
            <div class="d-flex justify-content-evenly pb-0">
              <p class="text-4"><i class="fa-solid fa-camera text-danger"></i> Photos/Videos</p>
              <p class="text-4"><i class="fa-solid fa-images text-success"></i> GIFs</p>
              <p class="text-4"><i class="fa-solid fa-face-smile-wink text-warning"></i> Feeling/Activity</p>
            </div>
          </div>
        </div>

        <!-- Featured Posts -->
        <!-- <div class="card my-3 mx-3 py-3 card-border card-border-top rounded">
          <div class="card-content px-4">
            <h4 class="heading heading-primary">Featured Posts</h4>
            <div class="carousel-half-full-width-wrapper">
              <div class="owl-carousel owl-theme show-nav-hover nav-inside" data-plugin-options="{ 'center': true, 'margin': 10, 'loop': true, 'autoplay': true, 'autoplayTimeout': 4000, 'nav': true, 'dots': false}">
                <div>
                  <img alt="no description" class="img-fluid" style="border-radius: 25px;" src="<?php echo '/files/sites/4/data/featured1.jpg'; ?>">
                </div>
                <div>
                  <img alt="no description" class="img-fluid" style="border-radius: 25px;" src="<?php echo '/files/sites/4/data/featured2.jpg'; ?>">
                </div>
                <div>
                  <img alt="no description" class="img-fluid" style="border-radius: 25px;" src="<?php echo '/files/sites/4/data/featured3.jpg'; ?>">
                </div>
                <div>
                  <img alt="no description" class="img-fluid" style="border-radius: 25px;" src="<?php echo '/files/sites/4/data/featured4.jpg'; ?>">
                </div>
              </div>
            </div>
          </div>
        </div> -->
          
        <!-- POSTS -->
        <div id="posts" class="col-md-12 pr-0">
          
        </div>
        <div class="load-more-posts-btn">
          <div id="tribe_posts_load_more" data-page="0" data-perPage="5" class="btn btn-primary bold">
            Load More 
          </div>
        </div>
        
      </div> 

      <!-- RIGHT COLUMN -->
      <div class="col-md-5">
      
        <!-- About -->
        <div class="card py-3 card-border card-border-top rounded">
          <div class="card-content px-4">
            <h4 class="heading heading-primary">About</h4>
            <div data-plugin-readmore data-plugin-options="{'buttonOpenLabel': 'See More <i class=\'fas fa-chevron-down text-2 ms-1\'></i>','buttonCloseLabel': 'See Less <i class=\'fas fa-chevron-up text-2 ms-1\'></i>'}">
              <p>Welcome to the Bulletproof Husband&trade; VIP!</p>
              <p class="mb-none">This group along with your weekly group coaching calls are your gateway to creating the long-term, consistent, happy, and fulfilling marriage you have always wanted.</p>
              <p>It is a privilege to be part of this group.</p>
              <p>The group is a secret group and highly confidential, safe place for men to seek the guidance they need.</p>
              <p>Purpose of this group is to:</p>
              <ul>
                <li>communicate about the weekly coaching calls</li>
                <li>have each others' back</li>
                <li>provide the support each men needs to rebuild their marriage and create the sustainable relationship they deserve</li>
                <li>ask the question you need to be the man you have always wanted to be</li> 
              </ul>
              <div class="readmore-button-wrapper d-none">
                <a href="#" class="text-decoration-none">See More<i class="fas fa-chevron-down"></i></a>
              </div>
            </div>
            <div class="mt-4">
              <h5 class="mb-0"><i class="fa fa-lock pr-5"></i> Private</h5>
              <p>Only members can see who's in the tribe and what they post.</p>
            </div>
            <div class="mt-4">
              <h5 class="mb-0"><i class="fa fa-eye-slash pr-5"></i> Hidden</h5>
              <p>This group is only accessible to members.</p>
            </div>
            <div class="mt-2">
              <a class="btn btn-primary bold" style="width: 100%" href="<?php //echo pageUserUrl( 'socialabout' ); ?>">Learn More</a>
            </div>
          </div>
        </div> 
             

        <!-- Tags -->
        <!-- <div class="card mt-4 py-3 card-border card-border-top rounded">
          <div class="card-content px-4">
            <h4 class="heading heading-primary">Popular Topics in the Tribe</h4>
            <div class="mt-2">
              <h4 class="py-0 my-0"><a>#bulletpullingcall</a></h4>
              <p class="mb-1">152 Posts</p>
            </div>
            <div class="mt-1">
              <h4 class="py-0 my-0"><a>#winning</a></h4>
              <p class="mb-1">132 Posts</p>
            </div>
            <div class="mt-1">
              <h4 class="py-0 my-0"><a>#betterme</a></h4>
              <p class="mb-1">55 Posts</p>
            </div>
            <div class="mt-1">
              <a class="btn btn-primary bold" style="width: 100%" href="<?php //echo pageUserUrl( 'socialtags' ); ?>">Learn More</a>
            </div>
          </div>
        </div>       -->

      <div>
      
    </div>
  </div>
</div>
