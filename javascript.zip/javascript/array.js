let color_name = ["Black", "Red", "Purple", "Green", "Aqua"];
let color_length = color_name.length;
console.log(color_length);

for(i = 0; i < color_length; i++){
    if(color_name[i] == "Purple"){
        color_name[i] = "Yellow";
        console.log(color_name[i]);
    }else{
        console.log(color_name[i]);
    }
}