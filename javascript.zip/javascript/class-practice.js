class Carname{
    constructor(name){
        // console.log(name);
        this.name = name;
    }
}

const myclass = new Carname("Ford");
console.log(myclass.name);