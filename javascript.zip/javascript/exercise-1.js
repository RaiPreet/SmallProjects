// exercise 1 - multyple each element by 2 and return all elements that are greater than 10.  

let arr = [2,3,4,6,8];
let arr1 = arr.map((curr_ele) => { 
    return curr_ele * 2;
} ).filter((curr_ele) => {
    return curr_ele < 10;
})

console.log(arr1);