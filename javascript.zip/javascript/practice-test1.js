var myname = "Priti";
// console.log(myname);

// var a = 10;
// var b = "10";
// console.log(typeof(a));
// console.log(typeof(b));
// console.log( a + b);
// console.log( 10 + "10");
// console.log( 9 - "5");
// console.log( "Java" + "Script");
// console.log( " " + " ");
// console.log( "Java" - "Script");

// Comparision Operator
// var x = 30;
// var y = 10;
// console.log( x == y);
// console.log( x != y);
// console.log( x > y);
// console.log( x >= y);
// console.log( x < y);
// console.log( x <= y);

// Logical Operator
var a = 10;
var b = 5;
var c = 15;
console.log( a > b && b > c);
console.log( a > b || b > c);
console.log(!(a > b || b > c));
console.log( 3 ** 3);

