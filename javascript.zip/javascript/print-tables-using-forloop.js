var x = 9;
for(i=1; i<=10;i++){
    console.log(x + " * " + i + " = " + x * i);
}