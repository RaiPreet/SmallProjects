let string1 = "";
let buttons = document.querySelectorAll('.button');
Array.from(buttons).forEach((button)=>{
    button.addEventListener('click', (e)=>{
        if( e.target.innerHTML == "CE"){
            string1 = "0";
            document.getElementById("top-bar").innerText = string1;
            string1 = "";
        }
        else if(e.target.innerHTML == "="){
            string1 = eval(string1);
            document.getElementById("top-bar").innerHTML = string1;
        }
        else{
            string1 =  string1 + e.target.innerHTML;
            document.getElementById("top-bar").innerHTML = string1;
            // console.log((e.target.innerHTML));
        }
    })
})
