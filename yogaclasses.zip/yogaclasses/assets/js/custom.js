window.onload = function () {
    window.onscroll = function(){
        if( document.body.scrollTop > 20 || document.documentElement.scrollTop > 20 ){
            gototop.style.display = "block";
        } 
        else {
            gototop.style.display = "none";
          }
        console.log("1");
    }

    // var moving_circle1 = document.getElementById("circle-container1");
    // let bottom_value = 600;
    // for(let i = 1; i < 5; i++){
    //     bottom_value = (bottom_value + 10) + "px";
    //     moving_circle1.style.bottom = bottom_value;
    //     alert(bottom_value);
        
    // }

}
